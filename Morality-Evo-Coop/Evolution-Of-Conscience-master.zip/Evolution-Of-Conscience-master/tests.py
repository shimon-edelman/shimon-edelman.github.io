import unittest
import numpy as np
import copy
from simulation import EvoModel
from simulation import Strategy
from simulation import GroupAgent
from simulation import IndivAgent

class TestEvoModel(unittest.TestCase):
    n = 20
    g = 5
    distrib = {
        "miscreant": 0.55,
        "deceiver": 0.3,
        "citizen": 0.1,
        "saint": 0.05
    }
    benefit = 5
    cost = 3
    fitness = 10
    p_coop = 0.8
    p_con = 0.2
    p_mig = 0.1
    mortality = 0.2
    p_diff = 0.1
    threshold = 0.3

    g2 = 1
    benefit2 = 6
    distrib2 = {
        "miscreant": 0.1,
        "deceiver": 0.4,
        "citizen": 0.4,
        "saint": 0.1
    }
    g3 = 2

    def initialize_model(self):
        model = EvoModel(
                    self.n,
                    self.g,
                    self.distrib,
                    self.benefit,
                    self.cost,
                    self.fitness,
                    self.p_coop,
                    self.p_con,
                    self.p_mig,
                    self.mortality,
                    self.p_diff,
                    self.threshold)
        return model

    def simple_even_model(self):
        model = EvoModel(
                    4,
                    3,
                    self.distrib,
                    self.benefit,
                    self.cost,
                    self.fitness,
                    self.p_coop,
                    self.p_con,
                    self.p_mig,
                    self.mortality,
                    self.p_diff,
                    self.threshold)
        return model

    def simple_odd_model(self):
        model = EvoModel(
                    3,
                    3,
                    self.distrib,
                    self.benefit,
                    self.cost,
                    self.fitness,
                    self.p_coop,
                    self.p_con,
                    self.p_mig,
                    self.mortality,
                    self.p_diff,
                    self.threshold)
        return model

    def test_indivs(self):
        model = EvoModel(
            self.n,
            self.g2,
            self.distrib2,
            self.benefit2,
            self.cost,
            self.fitness,
            self.p_coop,
            self.p_con,
            self.p_mig,
            self.mortality,
            self.p_diff,
            self.threshold,
            random=False)


        groups = list(model.group_table.keys())
        group = groups[0]
        indivs = model.group_table[group]

        # FIRST STEP INDIVS
        for indiv in indivs:
            indiv.step(random=False, smooth=True)

        # On the first round, miscreants and deceivers defect, while citizens
        # and saints cooperate.

        for indiv in indivs:
            self.assertEqual(indiv.fitness, model.fitness)
            self.assertEqual(indiv.observed, indiv.p_obs > 0.5)
            self.assertFalse(indiv.is_new_agent)
            strat = indiv.strategy
            if (strat == Strategy.MISCREANT or strat == Strategy.DECEIVER):
                self.assertEqual(indiv.p_coop, self.p_diff)
                self.assertFalse(indiv.cooperates)
            elif (strat == Strategy.CITIZEN):
                self.assertEqual(indiv.p_conscience, 1)
                self.assertEqual(indiv.p_coop, 1-self.p_diff)
                self.assertTrue(indiv.cooperates)
            elif (strat == Strategy.SAINT):
                self.assertEqual(indiv.p_coop, 1-self.p_diff)
                self.assertTrue(indiv.cooperates)


        # FIRST STEP GROUPS
        group.step_distrib()

        # 1/2 of the agents cooperate, and 1/2 defect.
        # 1/2 of the defectors are caught, so only 3/4 of the agents share in
        # the benefits of cooperation.
        self.assertEqual(group.num_cooperated, self.n/2)
        self.assertEqual(group.num_seen_cooperating, self.n/4)
        self.assertAlmostEqual(group.average_fitness, model.fitness + 0.5*model.benefit - 0.5*model.cost)
        self.assertAlmostEqual(group.average_benefit, (2/3)*model.benefit)

        for indiv in indivs:
            strat = indiv.strategy
            if (strat == Strategy.CITIZEN or strat == Strategy.SAINT) :
                self.assertAlmostEqual(indiv.fitness, model.fitness + (2/3)*model.benefit - self.cost)
            elif indiv.observed:
                self.assertEqual(indiv.fitness, model.fitness)
            else:
                self.assertAlmostEqual(indiv.fitness, model.fitness + (2/3)*model.benefit)

        ev_coop = indivs[-1].fitness
        ev_def_caught = indivs[1].fitness
        ev_def_not_caught = indivs[0].fitness


        # SECOND STEP INDIVS
        for indiv in indivs:
            indiv.step(random=False, smooth=True)

        for indiv in indivs:
            self.assertEqual(indiv.fitness, model.fitness)
            self.assertEqual(indiv.observed, indiv.p_obs > 0.5)
            self.assertFalse(indiv.is_new_agent)
            strat = indiv.strategy
            if (strat == Strategy.MISCREANT):
                self.assertEqual(indiv.p_coop, self.p_diff)
                self.assertFalse(indiv.cooperates)
            elif (strat == Strategy.DECEIVER):
                ev_def = indiv.p_obs*ev_def_caught + (1-indiv.p_obs)*ev_def_not_caught
                p_coop = (ev_coop / (ev_coop+ev_def))
                self.assertAlmostEqual(indiv.p_coop, p_coop)
                self.assertEqual(indiv.cooperates, p_coop > 0.5)
            elif (strat == Strategy.CITIZEN):
                if indiv.observed:
                    prop_other_coops = (self.n/4 - 1)/self.n
                else:
                    prop_other_coops = 1/4
                p_conscience = (prop_other_coops/self.threshold)*model.p_coop
                self.assertAlmostEqual(indiv.p_conscience, p_conscience)
                if (p_conscience > 0.5):
                    self.assertEqual(indiv.p_coop, 1-self.p_diff)
                    self.assertTrue(indiv.cooperates)
                else:
                    ev_def = indiv.p_obs*ev_def_caught + (1-indiv.p_obs)*ev_def_not_caught
                    p_coop = (ev_coop / (ev_coop+ev_def))
                    self.assertAlmostEqual(indiv.p_coop, p_coop)
                self.assertEqual(indiv.cooperates, p_coop > 0.5)
            elif (strat == Strategy.SAINT):
                self.assertEqual(indiv.p_coop, 1-self.p_diff)
                self.assertTrue(indiv.cooperates)


        # SECOND STEP GROUPS
        group.step_distrib()

        max_threshold1 = self.p_coop*((0.25*self.n-1)/self.n)*2
        max_threshold2 = self.p_coop*0.25*2

        # If threshold is below this value, all citizens will cooperate.
        # 1/2 of the deceivers (those more likely to be observed) will
        # cooperate, and 1/2 will defect.
        # All deceivers who cooperate will be seen cooperating, and none who
        # defect will be seen defecting.

        # num agents cooperating = all saints + all citizens + 1/2 deceivers
        # = .1 + .4 + .2 = .7
        # num seen cooperating = 1/2 saints + 1/2 citizens + 1/2 deceivers
        # = .05 + .2 + .2 = .45
        # num seen defecting = 1/2 miscreants = .05

        if (self.threshold < max_threshold1):
            self.assertEqual(group.num_cooperated, self.n*0.7)
            self.assertEqual(group.num_seen_cooperating, self.n*0.45)
            self.assertAlmostEqual(group.average_fitness, model.fitness + 0.7*model.benefit - 0.7*model.cost)
            self.assertAlmostEqual(group.average_benefit, (0.7/0.95)*model.benefit)

            coop_payoff = model.fitness + (0.7/0.95)*model.benefit - self.cost
            observed_def_payoff = model.fitness
            unobserved_def_payoff = model.fitness + (0.7/0.95)*model.benefit

            for indiv in indivs:
                strat = indiv.strategy
                expected_payoff = 0
                if (strat == Strategy.MISCREANT):
                    if indiv.observed:
                        expected_payoff = observed_def_payoff
                    else:
                        expected_payoff = unobserved_def_payoff
                elif (strat == Strategy.DECEIVER):
                    if indiv.p_obs > 0.5:
                        expected_payoff = coop_payoff
                    else:
                        expected_payoff = unobserved_def_payoff
                elif (strat == Strategy.CITIZEN or strat == Strategy.SAINT) :
                    expected_payoff = coop_payoff
                self.assertAlmostEqual(indiv.fitness, expected_payoff)

        # 1/2 of the deceivers and citizens (those more likely to be observed)
        # will cooperate, and 1/2 will defect.
        # All deceivers and citizens who cooperate will be seen cooperating,
        # and none who defect will be seen defecting.

        # num agents cooperating = 1/2 deceivers + 1/2 citizens + all saints
        # = .2 + .2 + .1 = .5
        # num seen cooperating = 1/2 deceivers + 1/2 citizens + 1/2 saints
        # = .2 + .2 + .05 = .45
        # num seen defecting = 1/2 miscreants = .05

        elif self.threshold > max_threshold2:
            self.assertEqual(group.num_cooperated, 0.5*self.n)
            self.assertEqual(group.num_seen_cooperating,0.45*self.n)
            self.assertAlmostEqual(group.average_fitness, model.fitness + 0.5*model.benefit - 0.5*model.cost)
            self.assertAlmostEqual(group.average_benefit, (0.5/0.95)*model.benefit)

            coop_payoff = model.fitness + (0.5/0.95)*model.benefit - self.cost
            observed_def_payoff = model.fitness
            unobserved_def_payoff = model.fitness + (0.5/0.95)*self.benefit2

            strat = indiv.strategy
            expected_payoff = 0
            for indiv in indivs:
                strat = indiv.strategy
                if (strat == Strategy.MISCREANT):
                    if indiv.observed:
                        expected_payoff = observed_def_payoff
                    else:
                        expected_payoff = unobserved_def_payoff
                elif (strat == Strategy.DECEIVER or strat == Strategy.CITIZEN):
                    if indiv.p_obs > 0.5:
                        expected_payoff = coop_payoff
                    else:
                        expected_payoff = unobserved_def_payoff
                elif (strat == Strategy.SAINT):
                    expected_payoff = coop_payoff
                self.assertAlmostEqual(indiv.fitness, expected_payoff)

    def test_death_and_reproduction(self):
        model = EvoModel(
            self.n,
            self.g2,
            self.distrib2,
            self.benefit2,
            self.cost,
            self.fitness,
            self.p_coop,
            self.p_con,
            self.p_mig,
            self.mortality,
            self.p_diff,
            self.threshold,
            random=False)

        groups = list(model.group_table.keys())
        group = groups[0]
        indivs = model.group_table[group]

        # fitnesses: [2,3,5,6]
        # comparative m_probs: [1.5, 1.25, .75, .5]
        # actual m_probs: [.3, .25, .15, .1]

        # Initialize strategies
        group.miscreants = 0
        group.deceivers = 0
        group.citizens = 0
        group.saints = 0

        n = model.n
        strategies = [Strategy.MISCREANT, Strategy.DECEIVER, Strategy.CITIZEN, Strategy.SAINT]
        fitnesses = [2,3,5,6]
        for i in range(n):
            indiv = indivs[i]
            j = i%4
            indiv.strategy = strategies[j]
            group.inc_strategy_count(strategies[j])
            indiv.fitness = fitnesses[j]
            indiv.is_new_agent = False
        group.average_fitness = 4

        dead_agent_inds = [4,8,12,16]
        dead_agents = []
        for ind in dead_agent_inds:
            dead_agents.append(indivs[ind])

        n_deaths = group.death(random=False)

        # Probability of dying
        all_indivs = list(model.indiv_table.keys()) + list(model.dead_indiv_table.keys())
        for indiv in all_indivs:
            if indiv.strategy == Strategy.MISCREANT:
                self.assertAlmostEqual(indiv.m_prob, .3)
            elif indiv.strategy == Strategy.DECEIVER:
                self.assertAlmostEqual(indiv.m_prob, .25)
            if indiv.strategy == Strategy.CITIZEN:
                self.assertAlmostEqual(indiv.m_prob, .15)
            elif indiv.strategy == Strategy.SAINT:
                self.assertAlmostEqual(indiv.m_prob, .1)

        new_expected_avg_fitness = (2 + 3*5 + 5*5 + 6*5)/16 # = 4.5
        self.assertEqual(group.average_fitness, new_expected_avg_fitness)

        # Number of agents of each kind
        self.assertEqual(group.miscreants, n//20)
        self.assertEqual(group.deceivers, n//4)
        self.assertEqual(group.citizens, n//4)
        self.assertEqual(group.saints, n//4)

        self.assertEqual(len(indivs), n*(1-model.mortality))

        for indiv in dead_agents:
            self.assertEqual(indiv.strategy, Strategy.MISCREANT)

        # Records in tables
        self.assertEqual(list(model.dead_indiv_table.keys()), dead_agents)
        self.assertEqual(len(model.group_table[group]), n*(1-model.mortality))
        self.assertEqual(len(model.indiv_table), n*(1-model.mortality))
        self.assertEqual(len(model.dead_indiv_table), n*model.mortality)

        for agent in all_indivs:
            if agent in dead_agents:
                self.assertIn(agent, model.dead_indiv_table)
                self.assertEqual(model.dead_indiv_table[agent], group)
                self.assertNotIn(agent, model.indiv_table)
                self.assertNotIn(agent, model.group_table[group])
            else:
                self.assertNotIn(agent, model.dead_indiv_table)
                self.assertIn(agent, model.indiv_table)
                self.assertEqual(model.indiv_table[agent], group)
                self.assertIn(agent, model.group_table[group])

        # Probability of reproducing
        total_fitness = new_expected_avg_fitness*n

        group.birth(n_deaths, random=False)
        # model.print_group_members()

        # Probabilities of reproducing
        num_remaining = n-n_deaths
        for indiv in indivs:
            if indiv.is_new_agent:
                self.assertEqual(indiv.r_prob, 0)
            else:
                if indiv.strategy == Strategy.MISCREANT:
                    self.assertAlmostEqual(indiv.r_prob, (2/4.5)/num_remaining)
                elif indiv.strategy == Strategy.DECEIVER:
                    self.assertAlmostEqual(indiv.r_prob, (3/4.5)/num_remaining)
                elif indiv.strategy == Strategy.CITIZEN:
                    self.assertAlmostEqual(indiv.r_prob, (5/4.5)/num_remaining)
                elif indiv.strategy == Strategy.SAINT:
                    self.assertAlmostEqual(indiv.r_prob, (6/4.5)/num_remaining)

        # Number of agents of each kind
        self.assertEqual(group.miscreants, n//20)
        self.assertEqual(group.deceivers, n//4)
        self.assertEqual(group.citizens, n//4)
        self.assertEqual(group.saints, 9*n//20)

        self.assertEqual(len(indivs),n)

        # Test to see if new agents were initialized correctly
        for i in range(n-n_deaths):
            self.assertFalse(indivs[i].is_new_agent)
        for i in range(n-n_deaths,n):
            indiv = indivs[i]
            self.assertTrue(indiv.is_new_agent)
            self.assertEqual(indiv.unique_id, "i" + str(i+n_deaths))
            self.assertEqual(indiv.strategy, Strategy.SAINT)

        # Records in tables
        self.assertEqual(len(model.group_table[group]), n)
        self.assertEqual(len(model.indiv_table), n)

        for agent in indivs:
            self.assertNotIn(agent, model.dead_indiv_table)
            self.assertIn(agent, model.indiv_table)
            self.assertEqual(model.indiv_table[agent], group)
            self.assertIn(agent, model.group_table[group])

    def test_entire_group_step(self):
        model = EvoModel(
            self.n,
            self.g3,
            self.distrib2,
            self.benefit2,
            self.cost,
            self.fitness,
            self.p_coop,
            self.p_con,
            self.p_mig,
            self.mortality,
            self.p_diff,
            self.threshold)


        groups = list(model.group_table.keys())
        group0 = groups[0]
        group1 = groups[1]
        indivs0 = model.group_table[group0]
        indivs1 = model.group_table[group1]

        groups = [group0, group1]
        indiv_lists = [indivs0, indivs1]

        for group in groups:
            group.miscreants = 0
            group.deceivers = 0
            group.citizens = 0
            group.saints = 0

        n = model.n
        strategies = [Strategy.MISCREANT, Strategy.DECEIVER, Strategy.CITIZEN, Strategy.SAINT]
        strat_props = [[2,8,8,2],[8,8,2,2]]
        for i in range(2):
            lst = strat_props[i]
            indiv_list = indiv_lists[i]
            group = groups[i]
            j = 0
            for s in range(4):
                num = strat_props[i][s]
                while (num > 0):
                    num -= 1
                    indiv = indiv_list[j]
                    indiv.strategy = strategies[s]
                    group.inc_strategy_count(strategies[s])
                    j += 1

        # FIRST STEP INDIVS
        for lst in indiv_lists:
            for indiv in lst:
                indiv.step(random=False, smooth=True)

        # On the first round, miscreants and deceivers defect, while citizens
        # and saints cooperate.
        for lst in indiv_lists:
            for indiv in lst:
                self.assertEqual(indiv.fitness, model.fitness)
                self.assertEqual(indiv.observed, indiv.p_obs > 0.5)
                self.assertFalse(indiv.is_new_agent)
                strat = indiv.strategy
                if (strat == Strategy.MISCREANT or strat == Strategy.DECEIVER):
                    self.assertEqual(indiv.p_coop, self.p_diff)
                    self.assertFalse(indiv.cooperates)
                elif (strat == Strategy.CITIZEN):
                    self.assertEqual(indiv.p_conscience, 1)
                    self.assertEqual(indiv.p_coop, 1-self.p_diff)
                    self.assertTrue(indiv.cooperates)
                elif (strat == Strategy.SAINT):
                    self.assertEqual(indiv.p_coop, 1-self.p_diff)
                    self.assertTrue(indiv.cooperates)


        # FIRST STEP GROUPS
        for i in range(2):
            # BASIC CHECKS FOR DEATH AND BIRTH
            group = groups[i]
            group.step_distrib()
            group.step_reproduce(random=False)
            new_indivs_list = indiv_lists[i]
            dead_indivs = model.group_table_dead_indivs[group]
            old_indivs_list = new_indivs_list + dead_indivs
            new_indivs = []
            for indiv in new_indivs_list:
                if indiv.is_new_agent:
                    new_indivs.append(indiv)
                    old_indivs_list.remove(indiv)
            self.assertEqual(len(new_indivs_list),n)
            self.assertEqual(len(new_indivs), len(dead_indivs))

            # COOPERATION STEP
            # [2,8,8,2]
            # 1/2 of the agents cooperate, and 1/2 defect.
            # 1/2 of the defectors are caught.
            if (i == 0):
                self.assertEqual(group.num_cooperated, self.n/2)
                self.assertEqual(group.num_seen_cooperating, self.n/4)
                self.assertAlmostEqual(group.average_benefit, (2/3)*model.benefit)

                for indiv in old_indivs_list:
                    strat = indiv.strategy
                    if (strat == Strategy.CITIZEN or strat == Strategy.SAINT) :
                        self.assertAlmostEqual(indiv.fitness, model.fitness + (2/3)*model.benefit - model.cost)
                    elif indiv.observed:
                        self.assertEqual(indiv.fitness, model.fitness)
                    else:
                        self.assertAlmostEqual(indiv.fitness, model.fitness + (2/3)*model.benefit)
                for indiv in new_indivs:
                    self.assertEqual(indiv.fitness, model.fitness + (2/3)*model.benefit)
            
            # [8,8,2,2]
            # 1/5 of the agents cooperate, and 4/5 defect.
            # 1/2 of the defectors are caught.
            elif (i == 1):
                self.assertEqual(group.num_cooperated, self.n*0.2)
                self.assertEqual(group.num_seen_cooperating, self.n*0.1)
                self.assertAlmostEqual(group.average_benefit, (0.2/0.6)*model.benefit)

                for indiv in old_indivs_list:
                    strat = indiv.strategy
                    if (strat == Strategy.CITIZEN or strat == Strategy.SAINT) :
                        self.assertAlmostEqual(indiv.fitness, model.fitness + (0.2/0.6)*model.benefit - model.cost)
                    elif indiv.observed:
                        self.assertEqual(indiv.fitness, model.fitness)
                    else:
                        self.assertAlmostEqual(indiv.fitness, model.fitness + (0.2/0.6)*model.benefit)
                for indiv in new_indivs:
                    self.assertEqual(indiv.fitness, model.fitness + (0.2/0.6)*model.benefit)
        
            # DEATH AND BIRTH STEP
            if (i == 0):

                # - cooperators: base fitness + 2/3*benefit - cost = 11
                # - defectors not caught: base fitness + 2/3*benefit = 14
                # defectors caught: base fitness = 10
                # average: base fitness - 1/2*cost + 1/2*benefit
                # The defectors who were caught have the lowest payoff, so 4.5
                # of them die off.

                # Probability of dying (individual fitness already tested)
                average_fitness = model.fitness - 1/2*model.cost + 1/2*model.benefit # = 11.5
                for indiv in old_indivs_list:
                    self.assertAlmostEqual(indiv.m_prob, model.mortality*(1+(average_fitness-indiv.fitness)/average_fitness))
                

                new_expected_avg_fitness = (1*10 + 5*14 + 10*11)/16 # = 11.875
                self.assertAlmostEqual(group.average_fitness, new_expected_avg_fitness)

                for indiv in dead_indivs:
                    self.assertIn(indiv.strategy, [Strategy.MISCREANT, Strategy.DECEIVER])
                    self.assertFalse(indiv.cooperates)
                    self.assertTrue(indiv.observed)

                # Records in tables
            
                for indiv in old_indivs_list:
                    if indiv in dead_indivs:
                        self.assertIn(indiv, model.dead_indiv_table)
                        self.assertEqual(model.dead_indiv_table[indiv], group)
                        self.assertNotIn(indiv, model.indiv_table)
                        self.assertNotIn(indiv, model.group_table[group])
                    else:
                        self.assertNotIn(indiv, model.dead_indiv_table)
                        self.assertIn(indiv, model.indiv_table)
                        self.assertEqual(model.indiv_table[indiv], group)
                        self.assertIn(indiv, model.group_table[group])

                # Probability of reproducing (individual fitnesses already tested)
                num_remaining = n - len(dead_indivs)
                total_fitness = new_expected_avg_fitness*num_remaining

                for indiv in new_indivs_list:
                    if indiv.is_new_agent:
                        self.assertEqual(indiv.r_prob, 0)
                    else:
                        self.assertAlmostEqual(indiv.r_prob, indiv.fitness/total_fitness)
                
                # Defectors who weren't caught are the most successful, so they
                # are the ones to reproduce.

                for indiv in new_indivs:
                    self.assertIn(indiv.strategy, [Strategy.MISCREANT, Strategy.DECEIVER])
                
                # Number of agents of each kind: 
                self.assertEqual(group.miscreants + group.deceivers, n//2)
                self.assertEqual(group.citizens, 2*n//5)
                self.assertEqual(group.saints, n//10)

                self.assertEqual(len(new_indivs_list),n)
            
            elif (i == 1):

                # - cooperators: base fitness + 1/3*benefit - cost = 9
                # - defectors not caught: base fitness + 1/3*benefit = 12
                # defectors caught: base fitness = 10
                # average: base fitness - 1/5*cost + 1/5*benefit = 10.6
                # The cooperators have the lowest payoff, so all of them die off.

                # Probability of dying (individual fitness already tested)
                average_fitness = model.fitness - 1/5*model.cost + 1/5*model.benefit # = 10.6
                for indiv in old_indivs_list:
                    self.assertAlmostEqual(indiv.m_prob, model.mortality*(1+(average_fitness-indiv.fitness)/average_fitness))
                

                new_expected_avg_fitness = (8*10 + 8*12)/16 # = 11.875
                self.assertAlmostEqual(group.average_fitness, new_expected_avg_fitness)
                
                for indiv in old_indivs_list:
                    if indiv in dead_indivs:
                        self.assertIn(indiv.strategy, [Strategy.CITIZEN, Strategy.SAINT])
                        self.assertTrue(indiv.cooperates)
                    else:
                        self.assertIn(indiv.strategy, [Strategy.MISCREANT, Strategy.DECEIVER])
                        self.assertFalse(indiv.cooperates)

                # Records in tables
                for indiv in old_indivs_list:
                    if indiv in dead_indivs:
                        self.assertIn(indiv, model.dead_indiv_table)
                        self.assertEqual(model.dead_indiv_table[indiv], group)
                        self.assertNotIn(indiv, model.indiv_table)
                        self.assertNotIn(indiv, model.group_table[group])
                    else:
                        self.assertNotIn(indiv, model.dead_indiv_table)
                        self.assertIn(indiv, model.indiv_table)
                        self.assertEqual(model.indiv_table[indiv], group)
                        self.assertIn(indiv, model.group_table[group])

                # Probability of reproducing (individual fitnesses already tested)
                num_remaining = n - len(dead_indivs)
                total_fitness = new_expected_avg_fitness*num_remaining

                for indiv in new_indivs_list:
                    if indiv.is_new_agent:
                        self.assertEqual(indiv.r_prob, 0)
                    else:
                        self.assertAlmostEqual(indiv.r_prob, indiv.fitness/total_fitness)
                
                # Defectors who weren't caught are the most successful, so they
                # are the ones to reproduce.

                for indiv in new_indivs:
                    self.assertIn(indiv.strategy, [Strategy.MISCREANT, Strategy.DECEIVER])
                
                # Number of agents of each kind: 
                self.assertEqual(group.miscreants + group.deceivers, n)
                self.assertEqual(group.citizens, 0)
                self.assertEqual(group.saints, 0)

                self.assertEqual(len(new_indivs_list),n)

    def test_constructor(self):

        model = self.initialize_model()

        for group, indivs in model.group_table.items():
            for indiv in indivs:
                self.assertEqual(group, model.indiv_table[indiv])

        self.assertEqual(model.curr_group_id, self.g)
        self.assertEqual(model.curr_indiv_id, self.g * self.n)

    def test_shuffle_and_pair(self):
        model = self.initialize_model()

        l = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

         # model.print_group_members()
         # model.print_group_composition()

        self.assertTrue(not bool(model.dead_indiv_table))
        self.assertTrue(not bool(model.dead_group_table))

        for indiv, group in model.indiv_table.items():
             self.assertIn(indiv, model.group_table[group])

        for group, indivs in model.group_table.items():
            for indiv in indivs:
                self.assertEqual(group, model.indiv_table[indiv])

        self.assertEqual(model.last_group_id, self.g - 1)
        self.assertEqual(model.last_indiv_id, self.g * self.n - 1)

    def test_shuffle_and_pair(self):
        model = self.initialize_model()

        l = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

        l1, l2 = model.shuffle_and_pair(l, random=False)
        self.assertEqual(l1, [1, 2, 3, 4, 5])
        self.assertEqual(l2, [6, 7, 8, 9, 10])

        l = [1, 2, 3, 4, 5, 6, 7, 8, 9]
        l1, l2 = model.shuffle_and_pair(l, random=False)
        self.assertEqual(l1, [1, 2, 3, 4])
        self.assertEqual(l2, [5, 6, 7, 8])

        l = [1, 2, 3, 4, 5, 6, 7]

        l1, l2 = model.shuffle_and_pair(l)
        self.assertEqual(len(l1), 3)
        self.assertEqual(len(l1), 3)

        l = [1, 2, 3, 4, 5, 6, 7, 8]
        l1, l2 = model.shuffle_and_pair(l)
        self.assertEqual(len(l1), 4)
        self.assertEqual(len(l2), 4)

    def test_swap_agents(self):
        model = self.initialize_model()

        indivs = list(model.indiv_table.keys())
        index_1 = len(indivs)//5
        index_2 = len(indivs)//2

        i1 = indivs[index_1]
        i2 = indivs[index_2]

        g1 = model.indiv_table[i1]
        g2 = model.indiv_table[i2]

        model.swap_agents(i1, i2)

        self.assertEqual(model.indiv_table[i1], g2)
        self.assertEqual(model.indiv_table[i2], g1)
        self.assertIn(i2, model.group_table[g1])
        self.assertIn(i1, model.group_table[g2])
        self.assertTrue(i1 not in model.group_table[g1])
        self.assertTrue(i2 not in model.group_table[g2])

    def test_replace_group(self):
        model = self.initialize_model()

        groups = list(model.group_table.keys())
        index_1 = 0
        index_2 = len(groups)//2

        winner = groups[index_1]
        loser = groups[index_2]

        indiv_winners = model.group_table[winner]
        indiv_losers = model.group_table[loser]

        new_group = model.replace_group(winner, loser)

        new_indivs = model.group_table[new_group]

        self.assertTrue(loser not in model.group_table)
        self.assertIn(loser, model.dead_group_table)
        for indiv in model.indiv_table:
            self.assertNotEqual(model.indiv_table[indiv], loser)

        self.assertIn(winner, model.group_table)
        self.assertTrue(winner not in model.dead_group_table)
        for indiv in model.group_table[winner]:
            self.assertTrue(indiv not in model.dead_indiv_table)

        self.assertIn(new_group, model.group_table)
        self.assertTrue(new_group not in model.dead_group_table)
        for indiv in model.group_table[new_group]:
            self.assertTrue(indiv not in model.dead_indiv_table)

        for indiv_loser in indiv_losers:
            self.assertEqual(model.dead_indiv_table[indiv_loser], loser)
            self.assertTrue(indiv_loser not in model.indiv_table)
            self.assertTrue(indiv_loser not in model.group_table[new_group])
            self.assertTrue(indiv_loser not in model.group_table[winner])

        for indiv_winner in indiv_winners:
            self.assertEqual(model.indiv_table[indiv_winner], winner)
            self.assertTrue(indiv_winner not in model.dead_indiv_table)
            self.assertTrue(indiv_winner not in model.group_table[new_group])
            self.assertTrue(indiv_winner not in model.dead_group_table[loser])

        for new_indiv in new_indivs:
            self.assertEqual(model.indiv_table[new_indiv], new_group)
            self.assertTrue(new_indiv not in model.dead_indiv_table)
            self.assertTrue(new_indiv not in model.group_table[winner])
            self.assertTrue(new_indiv not in model.dead_group_table[loser])

        self.assertEqual(new_group.miscreants, winner.miscreants)
        self.assertEqual(new_group.deceivers, winner.deceivers)
        self.assertEqual(new_group.citizens, winner.citizens)
        self.assertEqual(new_group.saints, winner.saints)

    def test_recombine_group(self):
        model = self.simple_even_model()
        indivs = [indiv for indiv in model.indiv_table]
        groups = [group for group in model.group_table]

        model.recombine_groups(random=False)
        self.assertEqual(model.indiv_table[indivs[0]], groups[1])
        self.assertEqual(model.indiv_table[indivs[1]], groups[1])
        self.assertEqual(model.indiv_table[indivs[2]], groups[2])
        self.assertEqual(model.indiv_table[indivs[3]], groups[2])
        self.assertEqual(model.indiv_table[indivs[4]], groups[2])
        self.assertEqual(model.indiv_table[indivs[5]], groups[2])
        self.assertEqual(model.indiv_table[indivs[6]], groups[0])
        self.assertEqual(model.indiv_table[indivs[7]], groups[0])
        self.assertEqual(model.indiv_table[indivs[8]], groups[0])
        self.assertEqual(model.indiv_table[indivs[9]], groups[0])
        self.assertEqual(model.indiv_table[indivs[10]], groups[1])
        self.assertEqual(model.indiv_table[indivs[11]], groups[1])

        self.assertEqual(set(model.group_table[groups[0]]), set({indivs[6], indivs[7], indivs[8], indivs[9]}))
        self.assertEqual(set(model.group_table[groups[1]]), set({indivs[0], indivs[1], indivs[10], indivs[11]}))
        self.assertEqual(set(model.group_table[groups[2]]), set({indivs[2], indivs[3], indivs[4], indivs[5]}))


        model = self.simple_odd_model()
        indivs = [indiv for indiv in model.indiv_table]
        groups = [group for group in model.group_table]

        model.recombine_groups(random=False)
        self.assertEqual(model.indiv_table[indivs[0]], groups[1])
        self.assertEqual(model.indiv_table[indivs[1]], groups[1])
        self.assertEqual(model.indiv_table[indivs[2]], groups[2])
        self.assertEqual(model.indiv_table[indivs[3]], groups[2])
        self.assertEqual(model.indiv_table[indivs[4]], groups[0])
        self.assertEqual(model.indiv_table[indivs[5]], groups[0])
        self.assertEqual(model.indiv_table[indivs[6]], groups[0])
        self.assertEqual(model.indiv_table[indivs[7]], groups[1])
        self.assertEqual(model.indiv_table[indivs[8]], groups[2])

        self.assertEqual(set(model.group_table[groups[0]]), set({indivs[4], indivs[5], indivs[6]}))
        self.assertEqual(set(model.group_table[groups[1]]), set({indivs[0], indivs[1], indivs[7]}))
        self.assertEqual(set(model.group_table[groups[2]]), set({indivs[2], indivs[3], indivs[8]}))

    def test_fight(self):
        model = self.initialize_model()

        groups = []
        for i, group in enumerate(model.group_table):
            group.average_fitness = i
            groups.append(group)

        self.assertEqual(model.fight(groups[0], groups[1], random=False), False)
        self.assertEqual(model.fight(groups[1], groups[2], random=False), False)
        self.assertEqual(model.fight(groups[2], groups[3], random=False), False)
        self.assertEqual(model.fight(groups[3], groups[4], random=False), False)
        self.assertEqual(model.fight(groups[4], groups[3], random=False), True)
        self.assertEqual(model.fight(groups[3], groups[2], random=False), True)
        self.assertEqual(model.fight(groups[2], groups[1], random=False), True)
        self.assertEqual(model.fight(groups[1], groups[0], random=False), True)

    def test_fight_groups(self):
        model = self.initialize_model()
        groups = []

        for i, group in enumerate(model.group_table):
            group.average_fitness = i
            groups.append(group)

        model.fight_groups(random=False)
        groups_new = [group for group in model.group_table]

        self.assertTrue(groups[0] not in groups_new)
        self.assertTrue(groups[1] not in groups_new)
        self.assertIn(groups[2], groups_new)
        self.assertIn(groups[3], groups_new)
        self.assertIn(groups[4], groups_new)

        model = self.simple_even_model()
        groups = []

        for i, group in enumerate(model.group_table):
            group.average_fitness = i
            groups.append(group)

        model.fight_groups(random=False)
        groups_new = [group for group in model.group_table]

        self.assertTrue(groups[0] not in groups_new)
        self.assertIn(groups[1], groups_new)
        self.assertIn(groups[2], groups_new)

if __name__ == "__main__":
    unittest.main()
