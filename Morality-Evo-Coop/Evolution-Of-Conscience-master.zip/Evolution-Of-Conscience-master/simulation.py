from mesa import Agent, Model
from mesa.time import RandomActivation
import mesa.space
import random
import numpy as np
import pandas as pd

import copy
from mesa.datacollection import DataCollector

from enum import Enum
from collections import defaultdict
from datetime import datetime
import os

class Strategy(Enum):
    MISCREANT = 1
    DECEIVER = 2
    CITIZEN = 3
    SAINT = 4

def is_group(agent):
    return agent.unique_id[0] == "g"

def is_indiv(agent):
    return agent.unique_id[0] == "i"

class IndivAgent(Agent):
    def __init__(self, unique_id, model, strategy, group, starting_fitness=0):
        super().__init__(unique_id, model)
        self.strategy = strategy
        self.fitness = starting_fitness
        self.observed = False
        self.cooperates = False
        self.default_choice = False
        self.is_new_agent = True
        self.p_obs = 0
        self.p_coop = 0 # testing purposes only
        self.p_conscience = 0
        self.migrated = False
        self.migration_partner = None
        self.m_prob = 0 # testing purposes only
        self.r_prob = 0 # testing purposes only

        self.model.curr_indiv_id = int(self.unique_id[1:]) + 1
        self.add_to_group(group)


    def add_to_group(self, group):
        self.model.indiv_table[self] = group
        self.model.group_table[group].append(self)
        group.inc_strategy_count(self.strategy)
        self.model.schedule.add(self)

    """
    - Fitness increases by baseline level
    - Agent is randomly assigned a probability of being observed
    (TODO: determine what function to use for assigning probability of being
    observed, currently using uniform [0,1])
    - Agent decides whether or not to cooperate
    - It is determined whether or not the agent will be observed
    """
    def step(self, random=True, smooth=False):
        self.fitness = self.model.fitness
        if random:
            p = self.random.uniform(0,1)
        else:
            id_num = int(self.unique_id[1:])
            if (id_num %2 == 0):
                p = 0.2
            else:
                p = 0.8
        self.p_obs = p
        self.cooperates = self.make_choice(random, smooth)
        if random:
            self.observed = self.random.choices([True, False], weights = [p, 1-p])[0]
        else:
            self.observed = (p > 0.5)
        self.is_new_agent = False
        self.migrated = False
        self.migration_partner = None

    def miscreant_choice(self, random=True):
        return self.final_choice(self.model.p_diff, random)

    """
    Returns probability of cooperating based on EV calculation.
    Takes into account the average reward that agents in this group received
    last time, cost for cooperating, and probablility of being observed.
    """

    def deceiver_choice(self, random=True, smooth=False):
        if self.is_new_agent:
            return self.miscreant_choice(random) # TODO maybe here make this a function of observation probability
        else:
            ev_coop, ev_def = self.calc_evs()
            p_coop = self.calc_prob_deceiver(ev_coop, ev_def, smooth)

            return self.final_choice(p_coop, random)

    def calc_evs(self):
        group = self.model.indiv_table[self]
        ev_coop = self.model.fitness + group.average_benefit - self.model.cost
        ev_def = self.p_obs*(self.model.fitness) + (1-self.p_obs)*(self.model.fitness + group.average_benefit)

        return ev_coop, ev_def

    def calc_prob_deceiver(self, ev_coop, ev_def, smooth):
        if smooth:
            p_coop = (ev_coop / (ev_coop + ev_def))
        else:
            p_coop = 1 - self.model.p_diff if ev_coop > ev_def else self.model.p_diff

        return p_coop

    def citizen_choice(self, random=True, smooth=False):
        if smooth:
            return self.citizen_smooth_choice(random)
        else:
            return self.citizen_binary_choice(random)

    def citizen_binary_choice(self, random=True):
        if self.is_new_agent:
            return self.saint_choice(random)
        else:
            group = self.model.indiv_table[self]
            num_other_cooperators = group.num_seen_cooperating - (self.cooperates and self.observed)
            prop_other_cooperators = num_other_cooperators/self.model.n

            if prop_other_cooperators >= self.model.threshold:
                return self.saint_choice(random)
            else:
                return self.deceiver_choice(random)

    def citizen_smooth_choice(self, random=True):
        if self.is_new_agent:
            self.p_conscience = 1
            p_coop = 1 - self.model.p_diff
        else:
            group = self.model.indiv_table[self]
            num_other_cooperators = group.num_seen_cooperating - (self.cooperates and self.observed)
            prop_other_cooperators = num_other_cooperators/self.model.n
            p_conscience = self.model.p_coop * min(prop_other_cooperators/self.model.threshold, 1)
            self.p_conscience = p_conscience

            # Make a choice to act based on conscience or selfish choice
            if random:
                conscience = self.random.choices([True, False], weights = [p_conscience, 1-p_conscience])[0]
            else:
                conscience = (p_conscience > 0.5)

            if conscience:
                return self.saint_choice(random)
            else:
                return self.deceiver_choice(self.p_obs, random)

        return self.final_choice(p_coop, random)

    def saint_choice(self, random=True):
        self.default_choice = True
        return self.final_choice(1 - self.model.p_diff, random)

    def final_choice(self, p_coop, random=True):
        self.p_coop = p_coop
        self.default_choice = (p_coop > 0.5)
        if random:
            return self.random.choices([True, False], weights = [p_coop, 1-p_coop])[0]
        else:
            return self.default_choice

    """
    Agent decides whether or not to cooperate. Returns True if agent
    cooperates, False otherwise.
    """
    def make_choice(self, random=True, smooth=False):
        if(self.strategy == Strategy.MISCREANT):
            return self.miscreant_choice(random)
        elif(self.strategy == Strategy.DECEIVER):
            return self.deceiver_choice(random, smooth)
        elif(self.strategy == Strategy.CITIZEN):
            return self.citizen_choice(random, smooth)
        elif(self.strategy == Strategy.SAINT):
            return self.saint_choice(random)


    def kill_indiv(self):
        group = self.model.indiv_table[self]
        self.model.dead_indiv_table[self] = group
        del self.model.indiv_table[self]
        group.dec_strategy_count(self.strategy)
        self.model.schedule.remove(self)
        self.model.group_table[group].remove(self)
        # Remove this table
        self.model.group_table_dead_indivs[group].append(self)

class GroupAgent(Agent):
    def __init__(self, unique_id, model):
        super().__init__(unique_id, model)
        self.num_cooperated = 0
        self.num_seen_cooperating = 0
        self.average_benefit = 0
        self.average_fitness = 0
        self.miscreants = 0
        self.deceivers = 0
        self.citizens = 0
        self.saints = 0
        self.strategies = [self.miscreants, self.deceivers, self.citizens, self.saints]
        self.fought = False
        self.enemy = None

        self.model.curr_group_id = int(unique_id[1:]) + 1
        self.model.group_table[self] = []
        self.model.schedule.add(self)

    def step_distrib(self):
        n_indivs = self.model.n
        self.cooperation()
        self.average_fitness = self.model.fitness + self.num_cooperated*(self.model.benefit-self.model.cost)/n_indivs

    def step_reproduce(self, random=True):
        n_deaths = self.death(random)
        self.birth(n_deaths, random)

    """
    Agents cooperate, and pay a cost for doing so.
    The benefits of cooperation are shared among all agents except those who
    were caught defecting.
    """
    def cooperation(self):
        self.num_cooperated = 0
        self.num_seen_cooperating = 0
        indivs = self.model.group_table[self]
        indivs_rewarded = []
        for indiv in indivs:
            if indiv.cooperates:
                indiv.fitness -= self.model.cost
                self.num_cooperated += 1
                indivs_rewarded.append(indiv)
                if indiv.observed:
                    self.num_seen_cooperating += 1
            elif not indiv.observed:
                indivs_rewarded.append(indiv)

        if len(indivs_rewarded) > 0:
            self.average_benefit = self.num_cooperated*self.model.benefit/len(indivs_rewarded)

            for indiv in indivs_rewarded:
                indiv.fitness += self.average_benefit

    """
    Some agents are chosen to die off. Probability of dying off is inversely
    proportional to comparative fitness (agent's fitness / average fitness).
    Average fitness is recalculated to exclude dead agents.
    Among surviving agents, some are chosen to reproduce, replacing the dead
    agents. Probability of reproducing is proportional to comparative fitness.
    """
    def death(self, random=True):
        n = self.model.n
        indivs = self.model.group_table[self]
        indivs_to_remove = []
        change_in_avg = 0
        f = self.average_fitness

        m_probs = [0]*n
        for i, indiv in enumerate(indivs):
            m_prob = min(max(self.model.mortality*(1 + (f-indiv.fitness)/f), 0), 1) # TODO maybe change this formula
            indiv.m_prob = m_prob
            m_probs[i] = m_prob

        if random:
            for i, indiv in enumerate(indivs):
                m_prob = m_probs[i]
                m = self.random.choices([True, False], weights = [m_prob, 1-m_prob])[0]
                if m:
                    indivs_to_remove.append(indiv)

        else:
            num_indivs_to_remove = round(n*self.model.mortality)
            inds_to_remove = np.argsort(m_probs, kind="stable")[-num_indivs_to_remove:]
            for ind in inds_to_remove:
                indivs_to_remove.append(indivs[ind])

        if len(indivs_to_remove) == n:
            indivs_to_remove = indivs_to_remove[:-1]
        for indiv in indivs_to_remove:
            change_in_avg += indiv.fitness
            indiv.kill_indiv()

        n_deaths = len(indivs_to_remove)
        new_total_fitness = (self.average_fitness*n - change_in_avg)

        # print("Avg fitness, avg fitness of dead guy:", self.average_fitness, change_in_avg/n_deaths if n_deaths > 0 else None)

        self.average_fitness = new_total_fitness/(n-n_deaths)
        return n_deaths

    def birth(self, n_deaths, random=True):
        n = self.model.n
        indivs = self.model.group_table[self]
        total_fitness = self.average_fitness*(n-n_deaths)
        weights = [0 for i in range(n - n_deaths)]

        for i, indiv in enumerate(indivs):
            indiv.r_prob = (indiv.fitness/total_fitness)
            weights[i] = indiv.r_prob

        if random:
            reproducer_indices = self.random.choices(range(n - n_deaths), weights = weights, k=n_deaths)
        else:
            reproducer_indices = np.argsort(weights, kind="stable")[-n_deaths:]

        reproducer_total_fitness = 0
        for ind in reproducer_indices:
            reproducing_indiv = indivs[ind]
            reproducer_total_fitness += reproducing_indiv.fitness
            new_indiv = IndivAgent("i" + str(self.model.curr_indiv_id), self.model, reproducing_indiv.strategy, self, reproducing_indiv.fitness)

        # print("Avg fitness, avg fitness of reproducer:", self.average_fitness, reproducer_total_fitness/n_deaths if n_deaths > 0 else None)
    def print_agents(self):
        indivs = self.model.group_table[self]
        print([indiv.unique_id for indiv in indivs])

    def initialize_strategy_counts(self):
        self.miscreants = 0
        self.deceivers = 0
        self.citizens = 0
        self.saints = 0

        for indiv in self.model.group_table[self]:
            if indiv.strategy == Strategy.MISCREANT:
                self.miscreants += 1
            elif indiv.strategy == Strategy.DECEIVER:
                self.deceivers += 1
            elif indiv.strategy == Strategy.CITIZEN:
                self.citizens += 1
            elif indiv.strategy == Strategy.SAINT:
                self.saints += 1

    def inc_strategy_count(self, strategy):
        if strategy == Strategy.MISCREANT:
            self.miscreants += 1
        elif strategy == Strategy.DECEIVER:
            self.deceivers += 1
        elif strategy == Strategy.CITIZEN:
            self.citizens += 1
        elif strategy == Strategy.SAINT:
            self.saints += 1

    def dec_strategy_count(self, strategy):
        if strategy == Strategy.MISCREANT:
            self.miscreants -= 1
        elif strategy == Strategy.DECEIVER:
            self.deceivers -= 1
        elif strategy == Strategy.CITIZEN:
            self.citizens -= 1
        elif strategy == Strategy.SAINT:
            self.saints -= 1

    def kill_group(self):
        dead_indivs = copy.copy(self.model.group_table[self])

        for dead_indiv in dead_indivs:
            dead_indiv.kill_indiv()

        del self.model.group_table[self]
        self.model.dead_group_table[self] = dead_indivs
        self.model.schedule.remove(self)


"""
A scheduler that activates each type of agent once per step, running
first all individuals and then all groups. Within each level, order is
random.
"""
class RandomActivationByLevel(RandomActivation):


    def __init__(self, model):
        super().__init__(model)
        self.agents_by_level = defaultdict(list)

    """
    Self -> None
    Executes the steps of each agent level in turn
    """
    def step(self):
        # print("Step:", self.steps)
        # print("Groups before step")
        # self.model.print_group_members()
        # self.model.print_group_composition()

        all_indivs = list(self.model.indiv_table.keys())
        self.model.random.shuffle(all_indivs)
        for indiv in all_indivs:
            indiv.step()
        # print("Groups after individual step")
        # self.model.print_group_members()
        # self.model.print_group_composition()

        all_groups = list(self.model.group_table.keys())
        self.model.random.shuffle(all_groups)
        for group in all_groups:
            group.step_distrib()

        # self.model.dc_mid.collect(model)
        for group in all_groups:
            group.step_reproduce()

        # print("Groups after group step")
        # self.model.print_group_members()
        # self.model.print_group_composition()

        self.model.fight_groups()
        # print("Groups after fighting step")
        # self.model.print_group_members()
        # self.model.print_group_composition()

        self.model.recombine_groups()
        # print("Groups after recombination step")
        # self.model.print_group_members()
        # self.model.print_group_composition()

        self.model.dc_end.collect(self.model)

        self.steps += 1
        self.time += 1



class EvoModel(Model):
    """
    **Tested**
    """
    def __init__(self, n, g, distrib, benefit, cost, fitness, p_coop, p_con, p_mig, mortality, p_diff, threshold, random = True):

        # initial_props is a dict specifying the initial proportions of
        # agents with each of the 4 strategies.

        self.n = n
        self.g = g

        self.average_payoff = 0
        self.benefit = benefit
        self.cost = cost
        self.fitness = fitness
        self.p_coop = p_coop
        self.p_con = p_con
        self.p_mig = p_mig
        self.mortality = mortality
        self.p_diff = p_diff
        self.threshold = threshold

        self.diff_sum = 0

        self.curr_group_id = 0
        self.curr_indiv_id = 0

        model_reporters = {
            "saints": lambda m: m.total_saints,
            "citizens": lambda m: m.total_citizens,
            "deceivers": lambda m: m.total_deceivers,
            "miscreants": lambda m: m.total_miscreants
        }
        agent_reporters = {}
        """
        agent_reporters = {
            "fitness": lambda a: a.fitness if is_indiv(a) else None,
            "strategy": lambda a: a.strategy if is_indiv(a) else None,
            "expected_cooperation": lambda a: a.default_choice if is_indiv(a) else None,
            "cooperated": lambda a: a.cooperates if is_indiv(a) else None,
            "group": lambda a: self.indiv_table[a].unique_id if is_indiv(a) else None,
            "num_cooperators": lambda a: a.num_cooperated if is_group(a) else None,
            "num_misc": lambda a: a.miscreants if is_group(a) else None,
            "num_dec": lambda a: a.deceivers if is_group(a) else None,
            "num_cit": lambda a: a.citizens if is_group(a) else None,
            "num_saint": lambda a: a.saints if is_group(a) else None,
            "average_fitness": lambda a: a.average_fitness if is_group(a) else None
        }
        """

        # datacollector to be used in the middle of the step, before the agents die
        self.dc_mid = DataCollector(
            model_reporters=model_reporters,
            agent_reporters=agent_reporters
        )

        """
        agent_reporters.update(
            {
                "migrated?": lambda a: a.migrated if is_indiv(a) else None,
                "migration_partner": lambda a: a.migration_partner.unique_id if is_indiv(a) and a.migration_partner is not None else None,
                "fought?": lambda a: a.fought if is_group(a) else None,
                "enemy": lambda a: (None if a.enemy is None else a.enemy.unique_id) if is_group(a) else None,
            }
        )


        for key in ["expected_cooperation", "cooperated", "num_cooperators"]:
            agent_reporters.pop(key)
        """

        # datacollector to be used at the end of the step, after the agents die
        self.dc_end = DataCollector(
            model_reporters=model_reporters,
            agent_reporters=agent_reporters
        )

        self.schedule = RandomActivationByLevel(self)

        if random:
            strategies = self.random.choices(
                        population=[Strategy.MISCREANT, Strategy.DECEIVER, Strategy.CITIZEN, Strategy.SAINT],
                        weights=[distrib["miscreant"], distrib["deceiver"], distrib["citizen"], distrib["saint"]],
                        k=n*g
                        )
        else:
            strategies = []
            possible_strats = [Strategy.MISCREANT, Strategy.DECEIVER, Strategy.CITIZEN, Strategy.SAINT]
            weights = [distrib["miscreant"], distrib["deceiver"], distrib["citizen"], distrib["saint"]]
            for i in range(g):
                for j in range(len(possible_strats)):
                    strategies += [possible_strats[j]] * (round(weights[j]*n))

        self.group_table = defaultdict(list)
        self.indiv_table = {}
        self.dead_group_table = defaultdict(list)
        self.dead_indiv_table = {}
        self.group_table_dead_indivs = defaultdict(list)

        for i in range(g):
            g_id = "g" + str(self.curr_group_id)
            group_agent = GroupAgent(g_id, self)
            self.schedule.add(group_agent)

            for j in range(n):
                i_id = "i" + str(self.curr_indiv_id)
                indiv_agent = IndivAgent(i_id, self, strategies[self.curr_indiv_id], group_agent, fitness)

        self.refresh_agent_total_counts()
        # for group in self.group_table:
        #     print(group.unique_id, ":", [indiv.unique_id for indiv in self.group_table[group]])

    """
    EvoModel -> None
    Pairs all groups, has them fight with probability p_con, and replaces the loser with the
    winner
    **Tested**
    """
    def fight_groups(self, random=True):
        # pair up groups (Future: use spatial proximity)
        groups1, groups2 = self.shuffle_and_pair(list(self.group_table.keys()), random)

        for g1, g2 in zip(groups1, groups2):
            # save enemy for datacollector
            g1.enemy = g2
            g2.enemy = g1

            fight = self.random.choices([True, False], weights=[self.p_con, 1 - self.p_con])[0]

            if fight or (not random):
                # store whether groups fought for datacollector
                g1.fought = True
                g2.fought = True

                w = self.fight(g1, g2, random)
                if w:
                    self.replace_group(g1, g2)
                    # differential = g1.average_fitness - g2.average_fitness
                    # self.diff_sum += differential
                    # print("differential:", differential)
                else:
                    self.replace_group(g2, g1)
                    # differential = g2.average_fitness - g1.average_fitness
                    # self.diff_sum += differential
                    # print("differential:", differential)


    """
    EvoModel -> None
    Pairs individuals randomly, and then with probability p, switches their group
    membership
    **Tested**
    """
    def recombine_groups(self, random=True):
        indivs1, indivs2 = self.shuffle_and_pair(list(self.indiv_table.keys()), random)

        for i1, i2 in zip(indivs1, indivs2):
            i1.migration_partner = i2
            i2.migration_partner = i1

            move = self.random.choices([True, False], weights=[self.p_mig, 1 - self.p_mig])[0]

            if move or (not random):
                i1.is_new_agent = True
                i1.migrated = True
                i2.is_new_agent = True
                i2.migrated = True
                self.swap_agents(i1, i2)

            # print("---------------------")
            # print(i1.unique_id, "-", i2.unique_id)
            # print(i1.migration_partner.unique_id, i2.migration_partner.unique_id)
            # print(i1.migrated, "-", i2.migrated)

    """
    EvoModel -> Boolean
    Gets two groups to fight, returns true if g1 wins
    **Tested**
    """
    def fight(self, g1, g2, random=True):
        F1 = g1.average_fitness
        F2 = g2.average_fitness

        p = 0.5*(1 + (F1 - F2)/(F1 + F2))

        if random:
            w = self.random.choices([True, False], weights=[p, 1 - p])[0]
        else:
            w = (F1 >= F2)

        return w

    """
    EvoModel GroupAgent GroupAgent -> GroupAgent
    Replaces loser with a new group with exactly the same agent strategy
    distribution as winner
    **Tested**
    """
    def replace_group(self, winner, loser):
        loser.kill_group()
        new_group = GroupAgent("g" + str(self.curr_group_id), self)

        for indiv in self.group_table[winner]:
            new_indiv = IndivAgent("i" + str(self.curr_indiv_id), self, indiv.strategy, new_group, indiv.fitness)

        return new_group

    """
    EvoModel List -> List List
    Takes a list, shuffles it, and returns two separate lists. Interpret the ith element of
    first list as paired with ith element of second. Throws out one random element if the
    List length is odd

    **Tested**
    """
    def shuffle_and_pair(self, deck, random=True):
        if random:
            self.random.shuffle(deck)

        midpoint = len(deck)//2
        first_half = deck[:midpoint]
        second_half = deck[midpoint:]

        if len(second_half) > len(first_half):
            second_half.pop()

        return first_half, second_half


    """
    EvoModel -> IndivAgent IndivAgent
    Switches the group membership of indiv1 and indiv2
    **Tested**
    """
    def swap_agents(self, indiv1, indiv2):
        group1 = self.indiv_table[indiv1]
        group2 = self.indiv_table[indiv2]

        self.indiv_table[indiv1] = group2
        self.indiv_table[indiv2] = group1

        self.group_table[group1].remove(indiv1)
        self.group_table[group1].append(indiv2)
        self.group_table[group2].remove(indiv2)
        self.group_table[group2].append(indiv1)

        group1.dec_strategy_count(indiv1.strategy)
        group1.inc_strategy_count(indiv2.strategy)
        group2.dec_strategy_count(indiv2.strategy)
        group2.inc_strategy_count(indiv1.strategy)

    """
    EvoModel -> None
    Prints out a representation of the groups
    **Tested**
    """
    def print_group_members_with_strategy(self):
        for group, indivs in self.group_table.items():
            print(group.unique_id + "- ", [indiv.unique_id + ": " + str(indiv.strategy.name) for indiv in indivs])

    """
    EvoModel -> None
    Prints out a representation of the groups
    **Tested**
    """
    def print_group_members(self):
        for group, indivs in self.group_table.items():
            print(group.unique_id + "- ", [indiv.unique_id for indiv in indivs])

    """
    EvoModel -> None
    Prints out the numbers of each strategy in each group
    **Tested**
    """
    def print_group_composition(self):

        strr = ""
        for group in self.group_table:
            strr += (group.unique_id + ": ")
            strr += ("miscreants: " + str(group.miscreants))
            strr += (", deceivers: " + str(group.deceivers))
            strr += (", citizens: " + str(group.citizens))
            strr += (", saints: " + str(group.saints) + "\n")

        print(strr)

    def print_overall_composition(self):
        self.refresh_agent_total_counts()

        print("Overall:")
        print("miscreants:", self.total_miscreants, ",", self.total_miscreants/(self.n * self.g))
        print("deceivers:", self.total_deceivers, ",", self.total_deceivers/(self.n * self.g))
        print("citizens:", self.total_citizens, ",", self.total_citizens/(self.n * self.g))
        print("saints:", self.total_saints, ",", self.total_saints/(self.n * self.g))

    def refresh_agent_total_counts(self):
        self.total_miscreants = 0
        self.total_deceivers = 0
        self.total_citizens = 0
        self.total_saints = 0

        for group in self.group_table:
            self.total_miscreants += group.miscreants
            self.total_deceivers += group.deceivers
            self.total_citizens += group.citizens
            self.total_saints += group.saints

    """
    EvoModel -> None
    Takes a step
    """
    def step(self):
        self.schedule.step()

        self.refresh_agent_total_counts()
        self.print_overall_composition()


if __name__ == "__main__":
    equal_distrib = {
        "miscreant": 0.25,
        "deceiver": 0.25,
        "citizen": 0.25,
        "saint": 0.25
    }
    model = EvoModel(
                    n=100,
                    g=50,
                    distrib=equal_distrib,
                    benefit=3.5,
                    cost=1,
                    fitness=4,
                    p_coop=0.8,
                    p_con=0.1,
                    p_mig=0.1,
                    mortality=0.5,
                    p_diff=0.05,
                    threshold=0.3)

    for t in range(200):
        model.step()

    print(model.diff_sum)
    model_df_mid = model.dc_mid.get_model_vars_dataframe()
    agent_df_mid = model.dc_mid.get_agent_vars_dataframe()
    model_df_end = model.dc_end.get_model_vars_dataframe()
    agent_df_end = model.dc_end.get_agent_vars_dataframe()


    model_df = model_df_mid.join(model_df_end, how='outer', lsuffix="_mid", rsuffix="_end")
    # agent_df = pd.merge(agent_df_mid, agent_df_end, how='outer', on=['Step', 'AgentID'], suffixes=["_mid", "_end"])
    # agent_df = agent_df.sort_values(by=["Step", "group_mid", "group_end"])
    # agent_df = agent_df.sort_index(axis=1)

    now = datetime.now()
    timestamp = now.strftime("%m%d_%H%M%S")
    model_filename = timestamp + "_model" + ".csv"
    # agent_filename = timestamp + "_agent" +".csv"

    model_df.to_csv(os.path.join("data", model_filename))
    # agent_df.to_csv(os.path.join("data", agent_filename))
