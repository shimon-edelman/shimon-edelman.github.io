import pandas as pd
import os

result_series = []

for filename in os.listdir("data/data_dump"):
    s = pd.read_pickle(os.path.join("data", "data_dump", filename))
    result_series.append(s)

print(s)


summary_df = pd.concat(result_series, axis=1).transpose()
summary_df["no_agents"] = summary_df["config"].str.split('_').str[0].astype(int)
summary_df["no_groups"] = summary_df["config"].str.split('_').str[1].astype(int)
summary_df["base_fitness"] = summary_df["config"].str.split('_').str[2].astype(int)
summary_df["benefit"] = summary_df["config"].str.split('_').str[3].astype(float)

summary_df.to_csv(os.path.join("data", f'summary.csv'))
