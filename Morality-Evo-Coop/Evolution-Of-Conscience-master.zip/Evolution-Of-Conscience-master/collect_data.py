import pandas as pd
from simulation import EvoModel

from datetime import datetime
import os

def run_trials(n, g, fitness, benefit, con, t, s):
    records = []

    for trial in range(t):

        equal_distrib = {
            "miscreant": 0.25,
            "deceiver": 0.25,
            "citizen": 0.25,
            "saint": 0.25
        }

        comeback_distrib = {
            "miscreant": 0.25,
            "deceiver": 0.73,
            "citizen": 0.01,
            "saint": 0.01
        }

        model = EvoModel(
                        n=n,
                        g=g,
                        distrib=equal_distrib,
                        benefit=benefit,
                        cost=1,
                        fitness=fitness,
                        p_coop=0.8,
                        p_con=con,
                        p_mig=0.1,
                        mortality=0.5,
                        p_diff=0.05,
                        threshold=0.3)

        records.append(run_model(model, s))

    print(records)
    results = pd.DataFrame.from_records(records, columns=['saints', 'citizens', 'deceivers', 'miscreants'])

    mean_results = results.mean(axis = 0)
    mean_results["config"] = f'{n}_{g}_{fitness}_{benefit}_{con}'

    return results, mean_results

def run_model(model, s):
    for step in range(s):
        model.step()

        total_agents = (model.total_saints
                        + model.total_citizens
                        + model.total_deceivers
                        + model.total_miscreants)

        if (model.total_saints + model.total_citizens == total_agents) or (model.total_miscreants + model.total_deceivers == total_agents):
            break

    model_list = [model.total_saints, model.total_citizens, model.total_deceivers, model.total_miscreants]

    return model_list

if __name__ == "__main__":
    result_series = []
    for n in [100]:
        for g in [100]:
            for con in [0.0, 0.1, 0.2, 0.3, 0.4]:
                for fitness in [2]:
                    for benefit in [3.5]:
                        print(n, g, fitness, benefit)
                        result_df, mean_results = run_trials(n, g, fitness, benefit, con, 20, 200)
                        result_series.append(mean_results)
                        now = datetime.now()
                        timestamp = now.strftime("%m%d_%H%M%S")
                        model_filename =  f'{timestamp}_{n}_{g}_{fitness}_{benefit}_{con}.csv'
                        result_df.to_csv(os.path.join("data", model_filename))
                for i, s in enumerate(result_series):
                    s.to_pickle(f'data/data_dump/{i}.pkl')


    summary_df = pd.concat(result_series, axis=1).transpose()
    summary_df.to_csv(os.path.join("data", f'{timestamp}_summary.csv'))
