import ethics_numpy as e
import numpy as np
import unittest
from datetime import datetime

start = datetime.now()

benefit_from_coop = 12
cost_to_def = 16
p_cost_power = 1
p_cost = 6

groups1 = e.form_groups(30, 3, initial_prop=.3, initial=True, with_seed=True, seed=0)
p = np.array([
    0,1,0,0,0,0,0,1,1,0,
    1,0,0,1,0,0,0,1,1,1,
    1,1,0,1,0,0,0,1,0,0
])
groups1test = np.zeros((30,4))
groups1test[:,0] = p
groups1test = groups1.reshape((3,10,4))

groups2 = np.copy(groups1)
groups2[:,:,2] = 24
e.signaling_stage(groups2)
n3 = [0,0,24,3]
p3 = [1,0,22,3]
n4 = [0,0,24,4]
p4 = [1,0,22,4]
n5 = [0,0,24,5]
p5 = [1,0,22,5]
groups2test = np.array([
    [n3,p3,n3,n3,n3,n3,n3,p3,p3,n3],
    [p5,n5,n5,p5,n5,n5,n5,p5,p5,p5],
    [p4,p4,n4,p4,n4,n4,n4,p4,n4,n4]])

p_groups3 = np.copy(groups2[1:3])
e.random_cooperation(p_groups3, True, with_seed=True, seed = 10)
cooperation = np.array([
    [1,0,0,1,0,0,0,1,0,0],
    [1,1,0,1,0,0,0,1,0,0]
])
groups3test = np.copy(groups2test[1:3])
groups3test[:,:,1] = cooperation

p_groups4 = np.copy(p_groups3)
e.cooperation(p_groups4, benefit_from_coop)
b3 = 3*benefit_from_coop/10
b4 = 4*benefit_from_coop/10
n4 = [0,0,24+b4,4]
pc4 = [1,1,20+b4,4]
pd4 = [1,0,22+b4,4]
n5 = [0,0,24+b3,5]
pc5 = [1,1,20+b3,5]
pd5 = [1,0,22+b3,5]
groups4test = np.array([
    [pc5, n5, n5, pc5, n5, n5, n5, pc5, pd5, pd5],
    [pc4, pc4, n4, pc4, n4, n4, n4, pc4, n4, n4]
])

p_groups5 = np.copy(p_groups4)
e.punishment_stage(p_groups5, p_cost_power, p_cost, cost_to_def)
pcost4 = p_cost/4
pcost5 = p_cost/5
n4 = [0,0,24+b4-cost_to_def,4]
pc4 = [1,1,20+b4-pcost4,4]
pd4 = [1,0,22+b4-cost_to_def-pcost4,4]
n5 = [0,0,24+b3-cost_to_def,5]
pc5 = [1,1,20+b3-pcost5,5]
pd5 = [1,0,22+b3-cost_to_def-pcost5,5]
groups5test = np.array([
    [pc5, n5, n5, pc5, n5, n5, n5, pc5, pd5, pd5],
    [pc4, pc4, n4, pc4, n4, n4, n4, pc4, n4, n4]
])

groups6 = e.first_round_interactions(groups1, 4, p_cost_power, p_cost,
benefit_from_coop, cost_to_def, with_seed=True, seed=10)
groups6test = np.reshape((np.append(groups5test, groups2test[0])),(3,10,4))
groups6test[2,:,3] = 0


p_groups7 = np.copy(groups6[:2])
e.random_cooperation(p_groups7, False, with_seed=True, seed = 20)
cooperation = np.array([
    [1,1,1,1,0,1,1,1,1,0],
    [1,1,1,1,1,0,0,1,1,1]
])
groups7test = np.copy(groups6test[:2])
groups7test[:,:,1] = cooperation

p_groups8 = np.copy(p_groups7)
p_groups9 = np.copy(p_groups7)
e.cooperation(p_groups9, benefit_from_coop)
b8 = 8*benefit_from_coop/10
d4 = [0,0,b8,4]
c4 = [0,1,b8-2,4]
pd4 = [1,0,b8,4]
pc4 = [1,1,b8-2,4]
d5 = [0,0,b8,5]
c5 = [0,1,b8-2,5]
pd5 = [1,0,b8,5]
pc5 = [1,1,b8-2,5]
groups9test = np.array([
    [pc5, c5, c5, pc5, d5, c5, c5, pc5, pc5, pd5],
    [pc4, pc4, c4, pc4, c4, d4, d4, pc4, c4, c4]
])
groups9test[:,:,2] += groups5test[:,:,2]

# p_groups5 = np.copy(p_groups4)
# e.punishment_stage(p_groups8, p_cost_power, p_cost, cost_to_def)
pcost4 = p_cost/4
pcost5 = p_cost/5
d4[2] -= cost_to_def
pc4[2] -= pcost4
pd4[2] -= (cost_to_def+pcost4)
d5[2] -= cost_to_def
pc5[2] -= pcost5
pd5[2] -= (cost_to_def+pcost5)
groups8test = np.array([
    [pc5, c5, c5, pc5, d5, c5, c5, pc5, pc5, pd5],
    [pc4, pc4, c4, pc4, c4, d4, d4, pc4, c4, c4]
])
groups8test[:,:,2] += 24
groups8test[:,:,2] += groups5test[:,:,2]

groups8 = np.copy(groups6)
groups8 = np.round(e.subsequent_interactions(groups8, 4, p_cost_power, p_cost,
benefit_from_coop, cost_to_def, with_seed=True, seed=20),5)
groups8zeros = np.copy(groups2test[0])
groups8zeros[:,2] += 24
groups8zeros[:,3] = 0
groups8test = np.round(np.reshape((np.append(groups8test, groups8zeros)),(3,10,4)),5)

class TestSmallerMethods(unittest.TestCase):
    def test_form_groups(self):
        self.assertTrue(np.array_equal(groups1, groups1test),
        "\nReturned:\n" + np.array2string(groups1) + "\nExpected:\n" + np.array2string(groups1test))
    def test_signaling_stage(self):
        self.assertTrue(np.array_equal(groups2, groups2test),
        "\nReturned:\n" + np.array2string(groups2) + "\nExpected:\n" + np.array2string(groups2test))
    def test_random_cooperation_p_only(self):
        self.assertTrue(np.array_equal(p_groups3, groups3test),
        "\nReturned:\n" + np.array2string(p_groups3) + "\nExpected:\n" + np.array2string(groups3test))
    def test_random_cooperation_all(self):
        self.assertTrue(np.array_equal(p_groups7, groups7test),
        "\nReturned:\n" + np.array2string(p_groups7) + "\nExpected:\n" + np.array2string(groups7test))
    def test_cooperation2(self):
        self.assertTrue(np.array_equal(p_groups9, groups9test),
        "\nReturned:\n" + np.array2string(p_groups9) + "\nExpected:\n" + np.array2string(groups9test))
    def test_cooperation(self):
        self.assertTrue(np.array_equal(p_groups4, groups4test),
        "\nReturned:\n" + np.array2string(p_groups4) + "\nExpected:\n" + np.array2string(groups4test))
    def test_punishment_stage(self):
        self.assertTrue(np.array_equal(p_groups5, groups5test),
        "\nReturned:\n" + np.array2string(p_groups5) + "\nExpected:\n" + np.array2string(groups5test))

class TestLargerMethods(unittest.TestCase):
    def test_first_round_interactions(self):
        self.assertTrue(np.array_equal(groups6,groups6test),
        "\nReturned:\n" + np.array2string(groups6) + "\nExpected:\n" + np.array2string(groups6test))
    def test_subsequent_round_interactions(self):
        self.assertTrue(np.array_equal(groups8,groups8test),
        "\nReturned:\n" + np.array2string(groups8) + "\nExpected:\n" + np.array2string(groups8test)
        + "\n" + np.array2string(groups8test-groups8))

if __name__ == '__main__':
    unittest.main()
