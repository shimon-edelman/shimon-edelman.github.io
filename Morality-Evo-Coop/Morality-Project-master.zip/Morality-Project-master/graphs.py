import matplotlib.pyplot as plt
import statistics as stat
import numpy as np
from scipy import stats as sts
import ethics as e
from datetime import datetime
import csv

start = datetime.now()

n = 33
folder = "C://Users//zoyas//Morality-Project_Private//New_Morality_Project//Round " + str(n) + "//"

plot_types = ["num_groups", "p_cost_power", "threshold", "p_cost"]

def plot(type):
    data = []
    if type == "num_groups":
        data = e.num_groups_effect()
    elif type == "p_cost_power":
        data = e.cost_to_punishers_effect()
    elif type == "threshold":
        data = e.threshold_effect()
    elif type == "p_cost":
        data = e.p_cost_effect()
    plt.plot(data[0], data[1], label = "biological")
    plt.plot(data[0], data[2], label = "cultural")
    plt.legend()
    graph_name = ''
    if type == "num_groups":
        graph_name = 'num_groups_vs_punisher_percent.png'
    elif type == "p_cost_power":
        graph_name = 'cost_to_punishers_multiplier_vs_punisher_percent.png'
    elif type == "threshold":
        graph_name = 'threshold_percentage_vs_punisher_percent.png'
    plt.savefig(graph_name)

def payoff_graph():
    stats = e.simulation("bio")
    data = e.payoff(stats[2])
    line1, = plt.plot(data[0], label = "punishers in punishing groups")
    line2, = plt.plot(data[1], label = "non-punishers in punishing groups")
    line3, = plt.plot(data[2], label = "punishers in non-punishing groups")
    line4, = plt.plot(data[3], label = "non-punishers in non-punishing groups")
    # line5, = plt.plot(data[4], label = "punisher average")
    # line6, = plt.plot(data[5], label = "non-punisher average")
    plt.legend(handles=[line1, line2, line3, line4])
    plt.savefig(folder + 'all_payoffs_graph.png')
    plt.close()

def graph_simulation_lite(n_years):
    y = e.bio_simulation_lite(n_years = n_years)
    x = list(range(0, n_years, 25))
    plt.plot(x, y, label = "percentage of punishers")
    plt.savefig(folder + "Simplified//punisher percentage")
    plt.close()

    increase_rate = []
    for i in range(1, len(x)):
        increase_rate.append(y[i] - y[i-1])
    plt.plot(x[1:], increase_rate)
    plt.savefig(folder + 'Simplified//rate of punisher population increase')
    plt.close()

# 28: 7,8
# 29: 6,10
# 30: 6,12
# 31: 6,10
# 32: 6,11

def graph_simulation(evo_type, n_agents = 2600, n_groups = 130, n_years = 10000,
                threshold_prop = .15, p_cost_power = 1, p_cost = 6,
                benefit_from_coop = 11, cost_to_def = 16, verbose_payoff = False,
                verbose_encounters = False):
    # # np_p: 28.8
    # # p_p: 27.1
    stats = e.simulation(evo_type, n_agents, n_groups, n_years, threshold_prop,
                       p_cost_power, p_cost, benefit_from_coop, cost_to_def,
                       verbose_payoff, verbose_encounters)
    # x = list(range(n_years+1))
    x = [0] + stats[3] + [n_years]
    p_percentages = stats[0]
    p_percentages_group = stats[1]
    payoffs = e.payoff(stats[2])
    averages = {}
    data_lists = [p_percentages, p_percentages_group] + payoffs
    labels = ["p_percent", "groups", "pp", "np", "pn", "nn", "p", "n"]
    for i in range(len(data_lists)):
        data = data_lists[i]
        label = labels[i]
        y = [data[0]]
        for i in range(1,len(x)):
            if data == p_percentages_group:
                y.append(data[x[i]-1])
            else:
                cycle = data[x[i-1]:x[i]]
                average = sum(cycle)/len(cycle)
                y.append(average)
        averages[label] = y
        # averages[label] = data # Remove later
    
    # # Find expected proportion of agents reproducing that are punishers
    expected_r_percentages_parent = []
    expected_r_percentages_child = []
    for i in range(len(averages["p"])):
        punishers_reproducing = averages["p_percent"][i] * averages["p"][i]
        non_punishers_reproducing = (100 - averages["p_percent"][i]) * averages["n"][i]
        proportion = punishers_reproducing * 100 / (punishers_reproducing + non_punishers_reproducing)
        expected_r_percentages_parent.append(proportion)
    averages["expected_r_parent"] = expected_r_percentages_parent

    data_rows = []
    for i in range(len(x)):
        new_row = {}
        for info_type in averages:
            new_row["year"] = x[i]
            new_row[info_type] = averages[info_type][i]
        data_rows.append(new_row)
    
    csv_file = folder + "CSV_File_" + str(n) + ".csv"
    with open(csv_file, 'w', newline = '') as output_file:
        writer = csv.DictWriter(output_file, fieldnames = ["year"] + list(averages.keys()))
        writer.writeheader()
        for row in data_rows:
            writer.writerow(row)

    plt.plot(x, averages["groups"])
    plt.savefig(folder + 'groups with punishers.png')
    plt.close()

    plt.plot(x, averages["p_percent"])
    plt.savefig(folder + 'prop of punishers.png')
    plt.close()

    line1, = plt.plot(x, averages["pp"], label = "punishers in punishing groups")
    line2, = plt.plot(x, averages["np"], label = "non-punishers in punishing groups")
    line3, = plt.plot(x, averages["pn"], label = "punishers in non-punishing groups")
    line4, = plt.plot(x, averages["nn"], label = "non-punishers in non-punishing groups")
    # line5, = plt.plot(data["p"], label = "punisher average")
    # line6, = plt.plot(data["n"], label = "non-punisher average")
    plt.legend(handles=[line1, line2, line3, line4])
    plt.savefig(folder + 'all_payoffs_graph.png')
    plt.close()

    slope, intercept, r_value, p_value, std_err = sts.linregress(x, averages["p"])
    line = list(map(lambda y: y*slope+intercept, x))
    line1, = plt.plot(x, averages["p"], label = "punisher average")
    # line2, = plt.plot(x, line, label = "punisher line")
    slope, intercept, r_value, p_value, std_err = sts.linregress(x, averages["n"])
    line = list(map(lambda y: y*slope+intercept, x))
    line3, = plt.plot(x, averages["n"], label = "non-punisher average")
    # line4, = plt.plot(x, line, label = "non-punisher line")
    plt.legend(handles=[line1, line3])
    plt.savefig(folder + 'payoff_graph.png')
    plt.close()

    line1, = plt.plot(x[:-1], averages["p_percent"][:-1], label = "percentage of punishers")
    line2, = plt.plot(x[:-1], averages["expected_r_parent"][:-1], label = "expected percentage of new agents that are punishers")
    line3, = plt.plot(x[:-1], averages["p_percent"][1:], label = "actual percentage of new agents that are punishers")
    plt.legend(handles=[line1, line2, line3])
    plt.savefig(folder + 'repro_and_p.png')
    plt.close()

    increase_rate = []
    for i in range(1, len(x)):
        increase_rate.append(averages["p_percent"][i] - averages["p_percent"][i-1])
    plt.plot(x[1:], increase_rate)
    plt.savefig(folder + 'rate of punisher population increase')
    plt.close()

    # graph_simulation_lite(n_years = n_years)

    diffs1 = []
    diffs2 = []
    for i in range(1,len(x)):
        diffs1.append(averages["p_percent"][i] - averages["expected_r_parent"][i-1])
        diffs2.append(averages["p_percent"][i] - averages["p_percent"][i-1])
    z1 = round(stat.mean(diffs1)/stat.stdev(diffs1),2)
    z2 = round(stat.mean(diffs2)/stat.stdev(diffs2),2)
    print(z1, z2)
    
def graph_simulation_average(evo_type, n_agents = 2600, n_groups = 130, n_years = 1500,
                threshold_prop = .15, p_cost_power = 2, p_cost = 3, benefit_from_coop = 10,
                cost_to_def = 16, verbose_payoff = True, verbose_encounters = False):
    stats_list = []
    num_simulations = 1
    sims = list(range(1,num_simulations+1))
    for sim in sims:
        print(sim)
        stats = e.simulation(evo_type, n_agents, n_groups, n_years, threshold_prop,
                    p_cost_power, benefit_from_coop, cost_to_def,
                    verbose_payoff, verbose_encounters)[0]
        stats_list.append(stats)
    stats_average = []
    years = list(range(0, n_years + 1))
    for year in years:
        total = 0
        for val in stats_list:
            total += val[year]
        avg = total/num_simulations
        stats_average.append(avg)
    #print(stats_average)
    plt.plot(years, stats_average)
    plt.ylabel('Average percentage of punishers in the population')
    plt.xlabel('Year')
    if evo_type == "bio":
        plt.savefig('bio1.png')
    elif evo_type == "cult":
        plt.savefig('cult1.png')

# graph_simulation_lite(1000)
graph_simulation("bio")

print(datetime.now() - start)