import random
from numpy.random import choice
from datetime import datetime
from functools import reduce

start = datetime.now()

"""
TO DO:
- Implement as numpy arrays
- See why simulation() gives different results from bio_simulation_lite()
- Create phase transition diagram
- Change how reproduction occurs
    - Reproduce if you surpass threshold payoff
    - Payoff decreases from reproducing
"""

def average_benefit_to_punisher(benefit_from_coop, cost_to_def, percent_def, cost_to_punishers):
    return (benefit_from_coop*(1-percent_def)
    - cost_to_def*percent_def
    - cost_to_punishers/3)

class Group():
    """
    Initializes a new group.
    Divides agents into categories of punishers and non-punishers.
    agents = the list of all agents in the group.
    punishers = the list of all punishers in the group.
    non_punishers = the list of all agents in the group who are not punishers.
    cooperators = the list of all agents that cooperated in this round.
    defectors = the list of all agents that defected in this round.
    previous_np = the number of agents who punished defectors in the previous round.
    """
    
    def __init__(self, agents):
        self.agents = agents
        self.punishers = []
        self.non_punishers = []
        for agent in agents:
            if agent.p_gene:
                self.punishers.append(agent)
            else:
                self.non_punishers.append(agent)
        self.cooperators = []
        self.defectors = []
        self.previous_np = 0
    
    def signaling_stage(self, threshold):
        """
        All punishers in the group signal their intent, and pay a cost for signaling.
        Determines whether the number of punishers reaches the threshold.
        Returns a boolen indicating whether or not there will be a punishment stage.
        """
        num_punishers = len(self.punishers)
        for agent in self.punishers:
                agent.payoff -= 3
        return num_punishers >= threshold
        
    def random_cooperation(self, agent_list):
        """
        All agents in the list are randomly assigned to cooperation or defection.
        They cooperate with probability .9 and defect with probability .1.
        """
        for agent in agent_list:
            action = choice(["cooperate", "defect"], 1, p = [.8, .2])[0]
            if action == "cooperate":
                self.cooperators.append(agent)
            else:
                self.defectors.append(agent)
    
    def first_round_interactions(self, threshold, p_cost_power, p_cost, benefit_from_coop, cost_to_def):
        """
        TODO: Change back to just returning one thing
        All non-punishers defect.
        If if enough punishers signaled, punishers are added to the list of
        cooperators with probability p. Then cooperation occurs, followed by a
        punishment stage.
        If not enough punishers signaled, then cooperation and punishment do
        not occur.
        Sets self.previous_np to the number of punishers that retaliated against
        defectors (to be used in subsequent_interactions).
        """
        for agent in self.agents:
            agent.payoff = 24
        p_above_threshold = self.signaling_stage(threshold)
        for agent in self.non_punishers:
            self.defectors.append(agent)
        self.cooperators = []
        if p_above_threshold:
            self.random_cooperation(self.punishers)
            self.cooperation(benefit_from_coop)
            self.previous_np, benefit_lost = self.punishment_stage(p_cost_power, p_cost, cost_to_def)
        else:
            self.previous_np = 0
        # for agent in self.agents:
        #     if agent.payoff < 4:
        #         print(agent.payoff)
        if self.previous_np < threshold:
            return 0, 0
        else:
            return 1, benefit_lost
    
    def subsequent_interactions(self, threshold, p_cost_power, p_cost, benefit_from_coop, cost_to_def):
        """
        TODO: Change back to just returning one thing
        If defectors were punished in the previous stage, all agents cooperate
        with probability p.
            If the number of punishers that retaliated in the last round
            exceeds the threshold, then the punishment stage occurs.
            Otherwise, punishment does not occur.
        If defectors were not punished last time, neither cooperation nor
        punishment occurs.
        """
        for agent in self.agents:
            agent.payoff += 24
        self.cooperators = []
        self.defectors = []
        p = 0
        # if self.previous_np >= threshold:
        if len(self.punishers) >= threshold: # TODO: Possibly replace with above statement later
            self.random_cooperation(self.agents)
            self.cooperation(benefit_from_coop)
            if self.punishers:
                p, benefit_lost = self.punishment_stage(p_cost_power, p_cost, cost_to_def)
        self.previous_np = p
        if p >= threshold:
            return 1, benefit_lost
        else:
            return 0, 0
    
    def cooperation(self, benefit_from_coop):
        """
        All cooperators pay a price for cooperating.
        The benefits of cooperation are summed and divided among all agents in
        the group.
        """
        for agent in self.cooperators:
            agent.payoff -= 2
        total_benefit = len(self.cooperators) * benefit_from_coop
        num_agents = len(self.agents)
        benefit = total_benefit / num_agents
        for agent in self.agents:
            agent.payoff += benefit
    
    def punishment_stage(self, p_cost_power, p_cost, cost_to_def):
        """
        TODO: Change back to just returning one thing.
        The cost to each punisher is determined according to the number of
        punishers.
        Punishers attack the defectors, thus decreasing payoff for the defectors.
        There is also a decrease in payoff for the punishers.
        Returns the number of punishers who retaliated against the defectors.
        """
        num_punishers = len(self.punishers)
        cost_to_punishers = p_cost/num_punishers
        for agent in self.defectors:
            agent.payoff -= cost_to_def
        for agent in self.punishers:
            agent.payoff -= cost_to_punishers
        return num_punishers, cost_to_punishers
    
    def age_up(self):
        """
        Children of agents in the group join the population. Returns the number of new agents.
        """
        new_agents = []
        num_new_agents = 0
        for agent in self.agents:
            for child in agent.children:
                num_new_agents += 1
                new_agents.append(child)
                if (child.p_gene):
                    self.punishers.append(child)
                else:
                    self.non_punishers.append(child)
        self.agents += new_agents
        return num_new_agents
    
    def update_punishers(self):
        self.punishers = []
        self.non_punishers = []
        for agent in self.agents:
            if agent.p_gene:
                self.punishers.append(agent)
            else:
                self.non_punishers.append(agent)
    
class Agent():
    
    def __init__(self, p_gene):
        """
        Initializes a new agent.
        payoff = payoff for this round, intialized at 0.
        fitness = payoff relative to other agents in this round, initialized to 0.
        p_gene = whether or not the agent is a punisher, as determined by its
            genetics.
        visible = whether or not the actions of this agent can be seen by other
            agents. Punishers cannot know whether invisible agents have defected.
            Initialized to True.
            (This attribute is not used in the current version of the
            simulation, but may be used in later versions.)
        thinks_visible = whether or not the agent believes it is visible.
            Initialized to True.
        child = the agent's new child, None if the agent has no new children.
            Initialized as the empty list.
        """
        self.payoff = 0
        self.fitness = 0
        self.p_gene = p_gene
        self.visible = True
        self.thinks_visible = True
        self.children = []
        self.group = Group([])
    
    def become_invisible(self):
        """
        The agent believes that it has become invisible.
        The agent actually becomes invisible with probability 90%, and remains
        visible with probability 10%.
        (This method is not used in the current version of the simulation, but
        may be used in later versions.)
        """
        thinks_visible = False
        visible = choice([True, False], 1, p = [.9, .1])[0]
    
    def reproduce(self):
        """
        The agent reproduces with a probability proportional to its fitness
        compared to the average fitness.
        The agent's offspring has the same tendency to either punish or not
        punish with a probability of 99%.
        The new agent is added to the list of this agent's children.
        Number of new agents born = 5% of the population.
        """
        f = self.fitness
        if f > 0:
            reproduces = choice([True, False], 1, p = [f, 1-f])[0]
            if reproduces:
                self.children.append(Agent(self.p_gene))
                if self.p_gene:
                    return 1
                else:
                    return 0
            else:
                return None
    
    def imitate(self, other, verbose = False):
        """
        Agent a with payoff Pa encounters agent b with payoff Pb.
        a imitates b with probability Pb/(Pa+Pb).
        When a imitates b, if b is a punisher, a becomes a punisher, and if b
        is a non-punisher, a becomes a non-punisher.
        """
        init_p = self.p_gene
        op = other.payoff
        sp = self.payoff
        if op < 0:
            op = 0
        prob_imitation = op/(op+sp)
        if sp < 0:
            prob_imitation = 1
        self.p_gene = choice([other.p_gene, self.p_gene], 1, p = [prob_imitation, 1-prob_imitation])[0]
        new_p = self.p_gene
        if init_p == False:
            if new_p == True:
                return -1
        elif new_p == False:
            return 1
        return 0
        
def get_next_gen(agents, n_agents):
    """
    Children of agents in the group join the population. Returns the number of new agents.
    """
    new_agents = []
    for agent in agents:
        new_agents += agent.children
        agent.children = []            
    return random.sample(new_agents, n_agents)

def calculate_fitness(agents, n_agents):
    """
    Sums the total payoff over all agents for this round.
    Calculates each agent's fitness in comparison to the average.
    """
    total_payoff = 0
    for agent in agents:
        if agent.payoff > 0:
            total_payoff += agent.payoff
    for agent in agents:
        if agent.payoff < 0:
            agent.fitness = 0
        else:
            if total_payoff > 0:
                agent.fitness = n_agents*.045*agent.payoff/total_payoff
            else:
                agent.fitness = 0
        
def form_groups(agent_list, n_groups):
    """
    Randomly divides the agents into the number of groups specified by num_groups.
    Returns a list containing the groups.
    """
    a_per_group = int(len(agent_list)/n_groups)
    groups = []
    random.shuffle(agent_list)
    for a in list(range(0, n_groups)):
        agents = (agent_list[0:a_per_group])
        group = (Group(agents))
        for agent in agents:
            agent.group = group
        groups.append(group)
        agent_list = agent_list[a_per_group:]
    return groups

def encounters(agent_list, group_list, m, verbose = False):
    """
    Each agent encounters another agent from its own group with probability m,
    or from another group with probability 1-m.
    (If all agents are in one group, each agent encounters another agent from
    its own group.)
    It then decides whether to imitate the other agent's strategy.
    (Note: currently, when agent a meets agent b, a may imitate b, but b does
    not imitate a. Might change this later.)
    """
    n = len(agent_list)
    if len(group_list) > 1:
        same_groups = choice([True, False], n, p = [m, 1-m])
    else:
        same_groups = [True] * n
    net_change = 0
    for i in list(range(0,n)):
        agent = agent_list[i]
        same_group = same_groups[i]
        if same_group:
            other_agents = agent.group.agents[:]
            other_agents.remove(agent)
            agent_encountered = random.choice(other_agents)
        else:
            other_groups = group_list[:]
            other_groups.remove(agent.group)
            group_encountered = random.choice(other_groups)
            agent_encountered = random.choice(group_encountered.agents)
        net_change += agent.imitate(agent_encountered, True)
        perc_change = (net_change/len(agent_list))*100
    for group in group_list:
        group.update_punishers()
    if verbose:
        print("% change " + str(round(perc_change, 1)))

def p_percent(groups, n_agents):
    """
    Returns the percentage of punishers in the population after this round.
    groups = list of all groups of agents
    n_agents = number of agents in the population
    """
    num_punishers = 0
    for group in groups:
        num_punishers += len(group.punishers)
    return (100*num_punishers/n_agents)

def payoff_printout(agents):
    num_agents = len(agents)
    total_payoff = 0
    for agent in agents:
        total_payoff += agent.payoff
    avg_payoff = round(total_payoff/num_agents,2)
    print("average payoff: " + str(avg_payoff))

def print_average_payoff(groups):
    pp = 0
    pn = 0
    np = 0
    nn = 0
    tpp = 0
    tpn = 0
    tnp = 0
    tnn = 0
    pg = 0
    ng = 0
    p_nums = []
    for group in groups:
        if group.previous_np == 0:
            ng += 1
            pn += len(group.punishers)
            for agent in group.punishers:
                tpn += agent.payoff
            nn += len(group.non_punishers)
            for agent in group.non_punishers:
                tnn += agent.payoff
        else:
            pg += 1
            pp += len(group.punishers)
            p_nums.append(len(group.punishers))
            payoff_dec = []
            for agent in group.punishers:
                tpp += agent.payoff
                payoff_dec.append(27.2 - agent.payoff/25)
            print(round(sum(payoff_dec)/len(payoff_dec),1))
            np += len(group.non_punishers)
            for agent in group.non_punishers:
                tnp += agent.payoff
    p = pp+pn
    tp = tpp+tpn
    n = np+nn
    tn = tnp+tnn
    agent_nums = [pp, np, pn, nn, p, n]
    payoffs = [tpp, tnp, tpn, tnn, tp, tn]
    percentages = []
    for i in range(6):
        if agent_nums[i] == 0:
            percentages.append(0)
        else:
            percentages.append(round(payoffs[i]/agent_nums[i], 2))
    # print(round(pp/pg,1))
    def get_payoff_decrease(current_payoff, num_p):
        return current_payoff + 6/num_p
    decrease_in_payoff = reduce(get_payoff_decrease, [0] + p_nums)
    print("Estimated decrease: " + str(round(6*pg/pp,2)))
    print("Expected decrease: " + str(round(decrease_in_payoff/pg,2)))
    print("Actual decrease: " + str(round((percentages[1] - percentages[0])/25,1)))
    return(percentages)

def evo(evo_type, agents, groups, n_agents, verbose_encounters, child_percentages, parent_percentages):
    """
    Successful agents pass on their strategy to others.
    If we are looking at biological evolution:
        Calculate the relative fitness of the agents.
        Based on this, decide which ones reproduce.
    If we are looking at cultural evolution:
        Agents copy other agents that are successful.
    """
    if evo_type == "bio":
        calculate_fitness(agents, n_agents)
        n_agents = 0
        n_punishers = 0
        new_agents = 0
        new_punishers = 0
        for agent in agents:
            n = agent.reproduce()
            if n != None:
                n_agents += 1
                if agent.p_gene:
                    n_punishers += 1
                new_agents += 1
                new_punishers += n
        child_percentages.append(new_punishers/new_agents * 100)
        parent_percentages.append(n_punishers/n_agents * 100)
    else:
        encounters(agents, groups, .5, verbose_encounters)

def evo_simplified(agents, n_agents):
    """
    Successful agents pass on their strategy to others.
    If we are looking at biological evolution:
        Calculate the relative fitness of the agents.
        Based on this, decide which ones reproduce.
    If we are looking at cultural evolution:
        Agents copy other agents that are successful.
    """
    p_agents = 0
    p_payoff = 0
    np_payoff = 0
    for agent in agents:
        if agent.p_gene:
            p_payoff += agent.payoff
            p_agents += 1
        else:
            np_payoff += agent.payoff
    np_agents = n_agents - p_agents
    num_new_p = int(p_payoff/(p_payoff+np_payoff)*n_agents)
    num_new_np = n_agents - num_new_p
    new_agentlist = []
    for i in range(num_new_p):
        new_agentlist.append(Agent(True))
    for i in range(num_new_np):
        new_agentlist.append(Agent(False))
    return new_agentlist

def simulation (evo_type, n_agents = 2600, n_groups = 130, n_years = 15000,
                threshold_prop = .15, p_cost_power = 1, p_cost = 6,
                benefit_from_coop = 11, cost_to_def = 16, verbose_payoff = False,
                verbose_encounters = False, simple_evo = True):
    """
    Args:
        evo_type:
            if "bio" then simulates biological evolution:
            agents pass on their strategy through reproduction.
            if "cult" then simulates cultural evolution:
            agents pass on their strategy when other agents copy them.
        n_agents: number of agents.
        n_groups: number of groups.
        n_years: number of years.
        threshold_prop: proportion of agents in a group that must be
            punishers in order for punishment to occur.
        p_cost_power: determines cost of punishing other agents,
            where cost = 3/(num_punishers)^(p_cost_power).
        verbose_payoff: if "True" prints information about the payoff for each
            agent.
        verbose_encounters: if "True" prints information about the encounters
            between agents.
    Returns:
        A pair of lists, where the first indicates how the percentage of
        punishers changed over the years,
        and the second indicates how the percentage of groups where punishment
        occurred changed over the years.
    """
    year = 0
    p_percentages_ind = []
    p_percentages_group = []
    payoffs = []
    parent_percentages = []
    child_percentages = []
    years_disbanded = []
    # Create agents. Randomly assign to be punishers or non-punishers.
    # Randomly assign to groups.
    agents = []
    for a in list(range(n_agents)):
        p_gene = choice([True, False], 1, p = [.1, .9])[0]
        agents.append(Agent(p_gene))
    groups = form_groups(agents, n_groups)
    p_groups = 0
    # Run first round of interactions.
    threshold = round (threshold_prop * (n_agents/n_groups))
    p_loss = 0
    for group in groups:
        inc, benefit_lost = group.first_round_interactions(threshold, p_cost_power,
        p_cost, benefit_from_coop, cost_to_def)
        p_groups += inc
        p_loss += benefit_lost
    a = []
    # Agents pass on their strategy.
    if not simple_evo:
        evo(evo_type, agents, groups, n_agents, verbose_encounters, child_percentages, parent_percentages)
    year += 1
    just_disbanded = False
    while year < n_years:
        if year%100 == 0:
            print (year)
        # groups_disband = choice([True, False], 1, p = [.04, .96])[0]
        groups_disband = year%25 == 0
        if groups_disband:
            years_disbanded.append(year)
            # Record stats.
            percent_p_groups = (100*p_groups/n_groups)
            p_percentages_group.append(percent_p_groups)
            p_percentages_ind.append(p_percent (groups, n_agents))
            payoffs.append(print_average_payoff(groups))
            if not simple_evo:
                agents = get_next_gen(agents, n_agents)
            else:
                agents = evo_simplified(agents, n_agents)
            if verbose_payoff:
                print ("~" * 25 + "New groups formed." + "~" * 25)
            groups = form_groups(agents, n_groups)
            p_groups = 0
            # Run first round of interactions.
            p_loss = 0
            for group in groups:
                inc, benefit_lost = group.first_round_interactions(threshold, p_cost_power,
                p_cost, benefit_from_coop, cost_to_def)
                p_groups += inc
                p_loss += benefit_lost
            # print("Payoff decrease: " + str(round(p_loss/p_groups,1)))
            # Record stats.
            # percent_p_groups = (100*p_groups/n_groups)
            # p_percentages_group.append(percent_p_groups)
            # p_percentages_ind.append(p_percent (groups, n_agents))
            # payoffs.append(payoffs.append(print_average_payoff(groups)))
            year += 1
            just_disbanded = True
            # Agents pass on their strategy.
            if not simple_evo:
                evo(evo_type, agents, groups, n_agents, verbose_encounters, child_percentages, parent_percentages)
            if year == n_years:
                break
        p_groups = 0
        # Run subsequent interactions.
        p_loss = 0
        for group in groups:
            inc, benefit_lost = group.subsequent_interactions(threshold, p_cost_power,
            p_cost, benefit_from_coop, cost_to_def)
            p_groups += inc
            p_loss += benefit_lost
        # Agents pass on their strategy.
        if not simple_evo:
            evo(evo_type, agents, groups, n_agents, verbose_encounters, child_percentages, parent_percentages)
        year += 1
    print(p_percentages_ind[-1])
    return [p_percentages_ind, p_percentages_group, payoffs, years_disbanded]

def payoffs(benefit_from_coop, cost_to_coop, cost_to_def, p_cost):
    np_payoff = 20 + 0.8 * benefit_from_coop - 0.2 * cost_to_def
    p_payoff = np_payoff - p_cost/3
    return (np_payoff, p_payoff)

def form_groups_lite(p_prop, n_agents, n_groups, threshold_prop):
    punishers = [1]*round(n_agents*p_prop)
    non_punishers = [0]*round(n_agents*(1-p_prop))
    agents = punishers + non_punishers
    random.shuffle(agents)
    p_groups = 0
    np_groups = 0
    p_p = 0
    p_np = 0
    np_p = 0
    np_np = 0
    group_size = int(n_agents/n_groups)
    threshold = threshold_prop*group_size
    for i in range(n_groups):
        group = agents[group_size*i:group_size*(i+1)]
        num_p = sum(group)
        if num_p < threshold:
            np_groups += 1
            p_np += num_p
            np_np += group_size-num_p
        else:
            p_groups += 1
            p_p += num_p
            np_p += group_size-num_p
    # if (p_p + np_p) == 0:
    #     print("No p groups")
    # elif (p_np + np_np) == 0:
    #     print ("No np groups")
    # else:
    #     print(round(p_p/(p_p+np_p),3), round(p_np/(p_np+np_np),3))
    return (p_groups, p_p, np_p, p_np, np_np)

def bio_simulation_lite(n_agents = 2600, n_groups = 130, n_years = 15000,
                threshold_prop = .15, p_cost_power = 1, p_cost = 6,
                benefit_from_coop = 11, cost_to_def = 16, mutation_rate = 0):
    p_prop = 0.1
    np_pgroup_payoff = 24 + .96*(0.8*(benefit_from_coop-2) - 0.2*(cost_to_def)) - .04*cost_to_def #24.8
    props = []
    for i in range(0, n_years, 25):
        p_groups, p_p, np_p, p_np, np_np = form_groups_lite(p_prop, n_agents, n_groups, threshold_prop)
        p_prop = (p_p + p_np) / (p_p + np_p + p_np + np_np)
        num_p_in_pgroup = p_p / p_groups
        num_p_in_npgroup = p_np / (n_groups - p_groups)
        p_pgroup_payoff = np_pgroup_payoff - p_cost/num_p_in_pgroup
        # print(round(num_p_in_pgroup,1))
        p_reproducing = p_pgroup_payoff*p_p + 24*p_np
        np_reproducing = np_pgroup_payoff*np_p + 24*np_np
        new_p_reproducing = p_reproducing*(1-mutation_rate) + np_reproducing*mutation_rate
        new_np_reproducing = np_reproducing*(1-mutation_rate) + np_reproducing*mutation_rate
        p_rate = new_p_reproducing/(new_p_reproducing + new_np_reproducing)
        # print(np_pgroup_payoff, round(p_pgroup_payoff,1))
        # print(round(p_rate - p_prop, 4)*100)
        p_prop = p_rate
        # if i%4 == 0:
        #     print(str(i) + ": " + str(round(p_prop*100,1)))
        props.append(p_prop*100)
    print(props[-1])
    # print(round(sum(props[-100:])/100,1))
    return props
 
def compare():
    """
    Informally compares results of cultural evolution simulation and biological
    evolution simulation.
    Just for testing purposes.
    """
    b_evo = 0
    c_evo = 0
    for i in list(range(0,100)):
        print(i)
        b_evo += simulation ("bio")
        c_evo += simulation ("cult")
    print(b_evo/100)
    print(c_evo/100)

def num_groups_effect():
    """
    Outputs a matrix for graphing the % of punishers at the end of the simulation
    against the number of groups.
    """
    y1 = []
    y2 = []
    x = [1,2,5,10,50,130]
    for i in list(range(0,len(x))):
        y1.append(simulation("bio", n_groups=x[i])[0][500])
        y2.append(simulation ("cult", n_groups=x[i])[0][500])
    print (str(i+1) + "/" + str(len(x)) + " complete") # To see progress
    return [x,y1,y2]

def cost_to_punishers_effect():
    """
    Outputs a matrix for graphing the % of punishers at the end of the simulation
    against the cost to the punishers.
    For each x, cost to punishers = 3/(num_punishers)^x.
    """
    y1 = []
    y2 = []
    x = [1,2,3,4]
    for i in list(range(0,len(x))):
        y1.append(simulation("bio", p_cost_power=x[i])[0][500])
        y1.append(simulation("cult", p_cost_power=x[i])[0][500])
    print (str(i) + "/" + str(len(x)) + " complete") # To see progress
    return [x,y1,y2]

def threshold_effect():
    """
    Outputs a matrix for graphing the % of punishers at the end of the simulation
    against the threshold for the percentage of punishers that must be in a
    group for punishment to occur.
    """
    y1 = []
    y2 = []
    x = [.05, .1, .15, .2, .25]
    for i in list(range(0, len(x))):
        y1.append(simulation("bio", threshold_prop=x[i])[0][500])
        y2.append(simulation("cult", threshold_prop=x[i])[0][500])
    print (str(i) + "/" + str(len(x)) + " complete")
    return [x,y1,y2]

def p_cost_effect():
    """
    Outputs a matrix for graphing the % of punishers at the end of the simulation
    against the cost of punishing another agent.
    """
    y1 = []
    y2 = []
    x = [2, 3, 4, 6, 8]
    for i in list(range(len(x))):
        y1.append(simulation("bio", p_cost = x[i])[0][500])
        y2.append(simulation("cult", p_cost = x[i])[0][500])
    print (str(i) + "/" + str(len(x)) + " complete")
    return [x,y1,y2]

def payoff(data):
    ys = [[], [], [], [], [], []]
    # data = simulation("bio")[2]
    for lst in data:
        for i in range(6):
            ys[i].append(lst[i])
    for lst in ys:
        for i in range(1, len(lst)-1):
            if (lst[i-1] + lst[i+1])/2 - lst[i] > 3.5 or (lst[i-1] + lst[i+1])/2 - lst[i] < -2.5:
                # print(lst[i-1], lst[i+1], lst[i])
                lst[i] = round((lst[i-1] + lst[i+1]) / 2, 2)
        lst[0] = lst[3]
        lst[1] = lst[3]
        lst[2] = lst[3]
    return ys

if __name__ == "__main__":
    # simulation("bio")
    bio_simulation_lite()
    print(datetime.now()-start)