import ethics as e
from numpy.random import choice
import unittest

"""
    Parameters set by Gintis:
    c = cost of cooperation = 0.01 -> 2
    b = benefit = .02 or .04 -> 4 or 8
    k = total cost to punishers = .015 -> 3
    q = cost of signaling = .015 -> 3
    p = .015 -> 3
    a = 2
    e = chance of defecting = 0.1
    n = group size = 18
    T = period before group disbands = 25
    time period = 1 year
    cost of being punished = .8 -> 16
    mutation rate = .01
    number of groups = 128 (or 130 for simplicity)
    
    My parameters:
    proportion born with p-gene: .1
    number of years = 500
"""    

a1 = e.Agent(True, 10)
a2 = e.Agent(True, 10)
a3 = e.Agent(False, 10)
a4 = e.Agent(False, 10)

b1 = e.Agent(True, 10)
b2 = e.Agent(False, 10)

g1 = e.Group([a1, a2, a3, a4])
g2 = e.Group([b1, b2])

agents = [a1, a2, a3, a4, b1, b2]
groups = [g1, g2]

class test_a_agent_init(unittest.TestCase):

    def test_punisher(self):
        self.assertEqual (a1.payoff, 0)
        self.assertEqual (a1.fitness, 0)
        self.assertTrue (a1.p_gene)
        self.assertEqual(a1.children, [])

    def test_nonpunisher(self):
        self.assertEqual (a3.payoff, 0)
        self.assertEqual (a3.fitness, 0)
        self.assertFalse (a3.p_gene)
        self.assertEqual (a3.children, [])

class test_b_group_init(unittest.TestCase):
    
    def test_2p_1np(self):
        self.assertEqual (g1.agents, [a1, a2, a3, a4])
        self.assertEqual (g1.punishers, [a1, a2])
        self.assertEqual (g1.non_punishers, [a3, a4])
        self.assertEqual (g1.cooperators, [])
        self.assertEqual (g1.defectors, [])
        self.assertEqual (g1.previous_np, 0)
    
    def test_1p_1np(self):
        self.assertEqual (g2.agents, [b1, b2])
        self.assertEqual (g2.punishers, [b1])
        self.assertEqual (g2.non_punishers, [b2])
        self.assertEqual (g2.cooperators, [])
        self.assertEqual (g2.defectors, [])
        self.assertEqual (g2.previous_np, 0)

class test_c_signaling_stage(unittest.TestCase):
    
    def test_g1(self):
        self.assertTrue(g1.signaling_stage(2))
        self.assertEqual(a1.payoff, -3)
        self.assertEqual(a2.payoff, -3)
        self.assertEqual(a3.payoff, 0)
    
    def test_g2(self):
        self.assertFalse(g2.signaling_stage(2))
        self.assertEqual(b1.payoff, -3)
        self.assertEqual(b2.payoff, 0)

class test_d_cooperation(unittest.TestCase):
    
    def test_payoff_g1 (self):
        g1.cooperators = [a1, a3]
        g1.defectors = [a2, a4]
        g1.cooperation()
        self.assertEqual (a1.payoff, -1)
        self.assertEqual (a2.payoff, 1)
        self.assertEqual (a3.payoff, 2)
        self.assertEqual (a4.payoff, 4)
    
    def test_payoff_g2 (self):
        g2.cooperators = []
        g2.defectors = [b1, b2]
        g2.cooperation()
        self.assertEqual (b1.payoff, -3)
        self.assertEqual (b2.payoff, 0)

class test_e_punishment_stage(unittest.TestCase):
    def test_payoff_g1 (self):
        g1.punishment_stage()
        self.assertEqual (a1.payoff, -1.75)
        self.assertEqual (a2.payoff, -15.75)
        self.assertEqual (a3.payoff, 2)
        self.assertEqual (a4.payoff, -12)

class test_f_fitness(unittest.TestCase):
    e.calculate_fitness (agents, 6)
    def test_fitness (self):
        self.assertEqual (a1.fitness, 0)
        self.assertEqual (a2.fitness, 0)
        self.assertEqual (a3.fitness, 6)
        self.assertEqual (a4.fitness, 0)
        self.assertEqual (b1.fitness, 0)
        self.assertEqual (b2.fitness, 0)


if __name__ == '__main__':
    unittest.main()