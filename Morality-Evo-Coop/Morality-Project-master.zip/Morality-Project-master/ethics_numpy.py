import random
import numpy as np
from datetime import datetime

start = datetime.now()

"""
Implemented as numpy arrays:
    - groups
        - agents
            - p_gene (0/1)
            - cooperator/defector (0/1)
            - payoff
TODO:
- Put lite simulation and stats tracking helpers in other files
"""

def signaling_stage(groups):
    """
    All punishers in the group signal their intent, and pay a cost for signaling.
    Determines whether the number of punishers reaches the threshold.
    Returns a boolean indicating whether or not there will be a punishment stage.
    """
    num_punishers = np.sum(groups[:,:,0], axis = 1)
    groups[:,:,2] -= 2*(groups[:,:,0])
    n_ps = np.transpose(np.full((groups.shape[1], groups.shape[0]), num_punishers))
    groups[:,:,3] = n_ps
    
def random_cooperation(groups, p_only, with_seed = False, seed=0):
    """
    All agents in the list are randomly assigned to cooperation or defection.
    They cooperate with probability .9 and defect with probability .1.
    """
    n_groups, n_per_group, _ = groups.shape
    if with_seed:
        print("SEED = " + str(seed))
        np.random.seed(seed)
    cooperation = np.random.choice(2, n_groups*n_per_group, p=[.2, .8])
    cooperation = cooperation.reshape(n_groups, n_per_group)
    if not p_only:
        groups[:,:,1] = cooperation
    else:
        cooperation = np.multiply(cooperation, groups[:,:,0])
    groups[:,:,1] = cooperation

def cooperation(groups, benefit_from_coop):
    """
    All cooperators pay a price for cooperating.
    The benefits of cooperation are summed and divided among all agents in the group.
    """
    groups[:,:,2] += groups[:,:,1] * -2
    benefit = np.sum(groups[:,:,1], axis = 1) * benefit_from_coop
    n_agents = groups.shape[1]
    benefit /= n_agents
    benefit_matrix = np.transpose(np.full((groups.shape[1], groups.shape[0]), benefit))
    groups[:,:,2] += benefit_matrix

def punishment_stage(groups, p_cost_power, p_cost, cost_to_def):
    """
    TODO: Change back to just returning one thing.
    The cost to each punisher is determined according to the number of
    punishers.
    Punishers attack the defectors, thus decreasing payoff for the defectors.
    There is also a decrease in payoff for the punishers.
    Returns the number of punishers who retaliated against the defectors.
    """
    num_punishers = np.sum(groups[:,:,0], axis = 1)
    cost_to_punishers = p_cost/(num_punishers**p_cost_power)
    p_cost_matrix = np.transpose(np.full((groups.shape[1], groups.shape[0]), cost_to_punishers))
    groups[:,:,2] -= ((1-groups[:,:,1]) * cost_to_def + groups[:,:,0] * p_cost_matrix)
    np_matrix = np.transpose(np.full((groups.shape[1], groups.shape[0]), num_punishers))
    groups[:,:,3] = np_matrix
    return cost_to_punishers

def first_round_interactions(groups, threshold, p_cost_power, p_cost,
benefit_from_coop, cost_to_def, with_seed = False, seed=0):
    """
    All non-punishers defect.
    If if enough punishers signaled, punishers are added to the list of
    cooperators with probability p. Then cooperation occurs, followed by a
    punishment stage.
    If not enough punishers signaled, then cooperation and punishment do
    not occur.
    Sets self.previous_np to the number of punishers that retaliated against
    defectors (to be used in subsequent_interactions).
    """
    def first_round_pgroups(groups):
        random_cooperation(groups, True, with_seed = with_seed, seed=seed)
        cooperation(groups, benefit_from_coop)
        benefit_lost = punishment_stage(groups, p_cost_power, p_cost, cost_to_def)
        return benefit_lost
    shape = groups.shape
    groups[:,:,2] = 24
    signaling_stage(groups)
    p_group_inds = (np.where(groups[:,0,3] >= threshold))
    np_group_inds = (np.where(groups[:,0,3] < threshold))
    p_groups = groups[p_group_inds]
    np_groups = groups[np_group_inds]
    np_groups[:,:,3] = 0
    benefit_lost = first_round_pgroups(p_groups)
    groups = np.append(p_groups, np_groups)
    groups = groups.reshape(shape)
    # return benefit_lost
    return groups

def subsequent_interactions(groups, threshold, p_cost_power, p_cost,
benefit_from_coop, cost_to_def, with_seed = False, seed=0):
    """
    If defectors were punished in the previous stage, all agents cooperate
    with probability p.
        If the number of punishers that retaliated in the last round
        exceeds the threshold, then the punishment stage occurs.
        Otherwise, punishment does not occur.
    If defectors were not punished last time, neither cooperation nor
    punishment occurs.
    """
    def next_round_pgroups(groups):
        random_cooperation(groups, False, with_seed = with_seed, seed=seed)
        cooperation(groups, benefit_from_coop)
        benefit_lost = punishment_stage(groups, p_cost_power, p_cost, cost_to_def)
        return benefit_lost
    def next_round_np_cgroups(groups):
        random_cooperation(groups, False, with_seed = with_seed, seed=seed+5)
        cooperation(groups, benefit_from_coop)
        groups[:,:,3] = 0
    shape = groups.shape
    groups[:,:,2] += 24
    p_c_group_inds = (np.where(groups[:,0,3] >= threshold))
    np_c_group_inds = (np.where(abs(groups[:,0,3] - threshold/2) < threshold/2))
    np_nc_group_inds = (np.where(groups[:,0,3] == 0))

    p_c_groups = groups[p_c_group_inds]
    np_c_groups = groups[np_c_group_inds]
    np_nc_groups = groups[np_nc_group_inds]

    benefit_lost = next_round_pgroups(p_c_groups)
    next_round_np_cgroups(np_c_groups)

    groups = np.append(p_c_groups, np_c_groups)
    groups = np.append(groups, np_nc_groups)
    groups = groups.reshape(shape)
    return groups
    # return benefit_lost


def form_groups(n_agents, n_groups, initial_prop = 0, agents = np.array([]),
initial = False, with_seed = False, seed = 0):
    """
    List of groups of agents -> list of groups with agents distributed differently.
    Randomly divides the agents into the number of groups specified by n_groups.
    Returns a list containing the groups.
    """
    if with_seed:
        np.random.seed(seed)
    if initial:
        agents = np.zeros((n_agents, 4))
        p_gene = np.random.choice(2, n_agents, p=[1 - initial_prop, initial_prop])
        agents[:,0] = p_gene
    else:
        np.random.shuffle(agents)
    new_groups = agents.reshape(n_groups, n_agents//n_groups, 4)
    return new_groups

def average_payoff(groups):
    agents = np.zeros(6) #pp, pn, np, nn, p, n
    payoffs = np.zeros(6)
    agents[0] = (sum(sum(np.where(groups[:,:,3] == 1, groups[:,:,0], 0))))
    agents[1] = (sum(sum(np.where(groups[:,:,3] == 1, 1-groups[:,:,0], 0))))
    agents[2] = (sum(sum(np.where(groups[:,:,3] == 0, groups[:,:,0], 0))))
    agents[3] = (sum(sum(np.where(groups[:,:,3] == 0, 1-groups[:,:,0], 0))))
    agents[4] = (agents[0] + agents[2])
    agents[5] = (agents[1] + agents[3])

    payoffs[0] = (sum(sum(np.where(groups[:,:,3] + groups[:,:,0] == 2, groups[:,:,2], 0))))
    payoffs[1] = (sum(sum(np.where(groups[:,:,3] - groups[:,:,0] == 1, groups[:,:,2], 0))))
    payoffs[2] = (sum(sum(np.where(groups[:,:,3] - groups[:,:,0] == -1, groups[:,:,2], 0))))
    payoffs[3] = (sum(sum(np.where(groups[:,:,3] + groups[:,:,0] == 0, groups[:,:,2], 0))))
    payoffs[4] = (payoffs[0] + payoffs[2])
    payoffs[5] = (payoffs[1] + payoffs[3])

    return(payoffs/agents)

def evo_simplified(groups):
    """
    Successful agents pass on their strategy to others.
    If we are looking at biological evolution:
        Calculate the relative fitness of the agents.
        Based on this, decide which ones reproduce.
    If we are looking at cultural evolution:
        Agents copy other agents that are successful.
    """
    n_agents = groups.shape[0] * groups.shape[1]
    this_gen = groups.reshape(n_agents, 4)
    p_payoff = sum(np.where(this_gen[:,0] == 1, this_gen[:,2], 0))
    np_payoff = sum(np.where(this_gen[:,0] == 0, this_gen[:,2], 0))
    num_new_p = int(p_payoff/(p_payoff+np_payoff)*n_agents)
    num_new_np = n_agents - num_new_p
    next_gen = np.zeros((n_agents, 4))
    next_gen[0:num_new_p,0] = 1
    return next_gen

def simulation (evo_type, n_agents = 2600, n_groups = 130, n_years = 15000,
                threshold_prop = .15, p_cost_power = 1, p_cost = 6,
                benefit_from_coop = 12, cost_to_def = 16, verbose_payoff = False,
                verbose_encounters = False, simple_evo = True, initial_prop = .1,
                with_seed = False):
    """
    Args:
        evo_type:
            if "bio" then simulates biological evolution:
            agents pass on their strategy through reproduction.
            if "cult" then simulates cultural evolution:
            agents pass on their strategy when other agents copy them.
        n_agents: number of agents.
        n_groups: number of groups.
        n_years: number of years.
        threshold_prop: proportion of agents in a group that must be
            punishers in order for punishment to occur.
        p_cost_power: determines cost of punishing other agents,
            where cost = 3/(num_punishers)^(p_cost_power).
        verbose_payoff: if "True" prints information about the payoff for each
            agent.
        verbose_encounters: if "True" prints information about the encounters
            between agents.
    Returns:
        A pair of lists, where the first indicates how the percentage of
        punishers changed over the years,
        and the second indicates how the percentage of groups where punishment
        occurred changed over the years.
    """
    year = 0
    p_percentages_ind = np.array([])
    p_percentages_group = np.array([])
    payoffs = np.array([])
    parent_percentages = np.array([])
    child_percentages = np.array([])
    years_disbanded = np.array([])
    if with_seed:
        seed = 0
    # Create agents. Randomly assign to be punishers or non-punishers.
    # Randomly assign to groups.
    groups = form_groups(n_agents, n_groups, initial = True, initial_prop = initial_prop, with_seed = with_seed, seed = seed)
    seed += 10
    p_groups = sum(np.where(groups[:,0,3] > 0))
    # Run first round of interactions.
    threshold = round (threshold_prop * (n_agents/n_groups))
    p_loss = 0
    groups = first_round_interactions(groups, threshold, p_cost_power, p_cost,
    benefit_from_coop, cost_to_def, with_seed=with_seed, seed=seed)
    seed += 10
    year += 1
    just_disbanded = False
    while year < n_years:
        if year%1000 == 0:
            print (year)
        groups_disband = year%25 == 0
        if groups_disband:
            years_disbanded = np.append(years_disbanded, year)
            # Record stats.
            p_groups = sum(np.where(groups[:,0,3] >= threshold, 1, 0))
            percent_p_groups = (100*p_groups/n_groups)
            p_percentages_group = np.append(p_percentages_group, percent_p_groups)
            p_percentages_ind = np.append(p_percentages_ind, (sum(sum(groups[:,:,0]))/n_agents))
            # print((sum(sum(groups[:,:,0]))/n_agents))
            payoffs = np.append(payoffs, (average_payoff(groups)))
            agents = evo_simplified(groups)
            if verbose_payoff:
                print ("~" * 25 + "New groups formed." + "~" * 25)
            groups = form_groups(n_agents, n_groups, agents = agents, with_seed=with_seed, seed=seed)
            seed += 10
            p_groups = sum(groups[:,0,3])
            # Run first round of interactions.
            p_loss = 0
            groups = first_round_interactions(groups, threshold, p_cost_power,
            p_cost, benefit_from_coop, cost_to_def, with_seed=with_seed, seed=seed)
            seed += 10
            year += 1
            just_disbanded = True
        p_groups = sum(groups[:,3,0])
        # Run subsequent interactions.
        p_loss = 0
        groups = subsequent_interactions(groups, threshold, p_cost_power, p_cost,
        benefit_from_coop, cost_to_def, with_seed=with_seed, seed=seed)
        seed += 10
        year += 1
    # After simulation has ended, record final stats.
    print(p_percentages_ind[0], p_percentages_ind[-1])
    return [p_percentages_ind, p_percentages_group, payoffs, years_disbanded]

if __name__ == "__main__":
    simulation("bio")
    print(datetime.now()-start)